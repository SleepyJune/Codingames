﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class MonsterTrading
    {
        public static Dictionary<Card, List<Trade>> trades = new Dictionary<Card, List<Trade>>();

        public static List<Trade> allSimulations = new List<Trade>();

        public static List<SimulationGroup> groupSimulations = new List<SimulationGroup>();

        public static void FindGroupSimulation()
        {
            var start = Timer.TickCount;

            FindTrades();

            Console.Error.WriteLine("End Trades: " + (Timer.TickCount - start));

            //FindAttackHeroCards();
            
            //allSimulations sort

            allSimulations = allSimulations.OrderBy(sim => sim is Trade ? 0 : 1).ToList();

            for (int i = 1; i <= 3 && i <= allSimulations.Count; i++)
            {
                int[] myCards = new int[i];
                GetSimulationCombination(myCards, 0, allSimulations.Count - 1, 0, i);
            }

            Console.Error.WriteLine("End Simulation: " + (Timer.TickCount - start));
        }

        public static void GetSimulationCombination(int[] data, int start, int end, int index, int numCards)
        {
            if (index == numCards)
            {
                SimulationGroup group = new SimulationGroup();
                                
                for (int i = 0; i < numCards; i++)
                {
                    var sim = allSimulations[data[i]];
                    if (!group.AddSimulation(sim))
                    {
                        return;
                    }
                }

                var possible = group.ComputeScore();
                if (possible)
                {
                    groupSimulations.Add(group);

                    //Console.Error.WriteLine(printString);
                }

                return;
            }

            for (int i = start; i <= end && end - i + 1 >= numCards - index; i++)
            {
                data[index] = i;
                GetSimulationCombination(data, i + 1, end, index + 1, numCards);
            }
        }

        public static void FindTrades()
        {
            var enemyCards = Player.enemy.cards
                .OrderBy(c => c.hasGuard ? 0 : 1)
                .ThenByDescending(c => c.health);

            var print = "";
            foreach(var card in Player.me.usableCards)
            {
                print += card.id + " ";
            }

            Console.Error.WriteLine("Useable Cards: " + print);

            foreach (var enemy in enemyCards)
            {
                if (enemy.health > 0 && (enemy.attack > 0 || enemy.hasGuard))
                {                    
                    GetTradeOptions(enemy);
                }
            }
        }
        
        public static void GetTradeOptions(Card target)
        {
            for (int i = 1; i < 4 && i <= Player.me.usableCards.Count; i++)
            {
                GetTradeOptionsHelper(target, i);
            }
        }

        public static void GetTradeOptionsHelper(Card target, int numCards)
        {
            int[] myCards = new int[numCards];
            GetTradeCombination(target, myCards, 0, Player.me.usableCards.Count-1, 0, numCards);
        }

        public static void GetTradeCombination(Card target, int[] data, int start, int end, int index, int numCards)
        {
            if (index == numCards)
            {
                Trade newTrade = new Trade(target);
                                
                for(int i=0;i<numCards;i++)
                {
                    var card = Player.me.usableCards[data[i]];
                    newTrade.AddCard(card);                    
                }
                                
                var killable = newTrade.ComputeScore();
                if (killable)
                {
                    if (true)//target.hasGuard || newTrade.GetScore() >= 5) //testing
                    {
                        AddTrade(target, newTrade);
                    }

                    newTrade.Print();
                }

                return;
            }

            for (int i = start; i <= end && end - i+1 >= numCards - index; i++)
            {
                data[index] = i;// Player.me.usableCards[i].id;
                GetTradeCombination(target, data, i + 1, end, index + 1, numCards);
            }
        }

        public static void AddTrade(Card target, Trade trade)
        {
            List<Trade> tradeList;
            if (trades.TryGetValue(target, out tradeList))
            {
                tradeList.Add(trade);
            }
            else
            {
                tradeList = new List<Trade>();
                tradeList.Add(trade);
                trades.Add(target, tradeList);
            }

            allSimulations.Add(trade);
        }

        public static void CleanUp()
        {
            trades = new Dictionary<Card, List<Trade>>();
            allSimulations = new List<Trade>();
            groupSimulations = new List<SimulationGroup>();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class SimulationGroup
    {
        public static int maxAttackHeroScore = 0;

        public List<Trade> simulations;

        HashSet<Card> simulationCards;

        HashSet<Card> tauntCardsKilled;

        int simulatedManaCost;

        float score;

        int heroHealth;

        int attackHeroScore;

        public SimulationGroup()
        {
            simulations = new List<Trade>();
            simulationCards = new HashSet<Card>();

            tauntCardsKilled = new HashSet<Card>();

            heroHealth = Player.enemy.health;

            attackHeroScore = maxAttackHeroScore;
        }

        public bool AddSimulation(Trade trade)
        {
            if (trade != null && simulationCards.Contains(trade.target))
            {
                return false;
            }

            if (simulationCards.Overlaps(trade.GetCards()))
            {
                return false;
            }

            if (Player.enemy.tauntCards.Count > 0 && tauntCardsKilled.Count < Player.enemy.tauntCards.Count)
            {
                //enemy has taunt cards and player has not killed them all yet

                if (trade != null)
                {                    
                    if (Player.enemy.tauntCards.Contains(trade.target))
                    {
                        tauntCardsKilled.Add(trade.target);
                    }
                    else
                    {
                        if (trade.myCards.Count == 1 && trade.myCards.First().isSpellCard)
                        {
                            //Console.Error.WriteLine("SpellCard Taunt " + trade.target.id + ": " + trade.GetScore());
                            //spell cards can go through taunt
                        }
                        else
                        {
                            return false; //cannot attack target without killing taunt cards
                        }
                    }
                }
            }

            attackHeroScore -= trade.totalAttack;
            simulatedManaCost += trade.simulatedManaCost;

            if (simulatedManaCost > Player.me.mana)
            {
                return false;
            }
                        
            simulations.Add(trade);

            foreach (var card in trade.GetCards())
            {
                simulationCards.Add(card);
            }

            score += trade.GetScore();

            return true;
        }

        public void Print()
        {
            string printString = "Group: ";

            foreach (var sim in simulations)
            {
                foreach (var card in sim.GetCards())
                {
                    printString += card.id + " ";
                }

                printString += ", ";
            }

            printString += "Score: " + score + " Hero: " + attackHeroScore;

            Console.Error.WriteLine(printString);
        }

        public bool ComputeScore()
        {
            if (!(Player.enemy.tauntCards.Count > 0 && tauntCardsKilled.Count < Player.enemy.tauntCards.Count))
            {
                //Kill hero in this turn
                if (attackHeroScore >= Player.enemy.health)
                {
                    score = 9999;
                }
                else
                {
                    if (!Player.enemy.hasLethal)
                    {
                        score += attackHeroScore;
                    }
                }
            }

            return true;
        }

        public float GetScore()
        {
            return score;
        }

        public HashSet<Card> GetCards()
        {
            return simulationCards;
        }
    }
}

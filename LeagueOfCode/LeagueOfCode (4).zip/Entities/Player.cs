﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class Player
    {
        public static Player me = new Player();
        public static Player enemy = new Player();

        public int health;
        public int mana;
        public int numCards;
        public int rune;

        public int numCardsOnBoard;

        public bool hasLethal;

        public List<Card> cards = new List<Card>();
        public List<Card> boardCards = new List<Card>();
        public List<Card> handCards = new List<Card>();

        public List<Card> usableCards = new List<Card>();

        public List<Card> tauntCards = new List<Card>();

        public Card highestCardOnBoard;

        public static void ProcessPlayers()
        {
            Player.enemy.CheckLethal();
            Player.me.HighestBoardCard();
        }

        public void HighestBoardCard()
        {
            highestCardOnBoard = Player.me.boardCards.OrderByDescending(c => c.cost).FirstOrDefault();
        }

        public void CheckLethal()
        {
            int totalAttack = Player.enemy.boardCards.Sum(c => c.attack);
            
            if (totalAttack >= Player.me.health)
            {
                Player.enemy.hasLethal = true;
            }
            else
            {
                Player.enemy.hasLethal = false;
            }
        }

        public static void CleanUp()
        {
            for (int i = 0; i < 2; i++)
            {
                Player player;
                if (i == 0)
                {
                    player = me;
                }
                else
                {
                    player = enemy;
                }
                                
                player.cards = new List<Card>();
                player.boardCards = new List<Card>();
                player.handCards = new List<Card>();
                player.usableCards = new List<Card>();
                player.numCardsOnBoard = 0;

                player.tauntCards = new List<Card>();
                //player.highestCardOnBoard = new List<Card>();
            }
        }
    }
}

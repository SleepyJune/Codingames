﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    interface Simulation
    {
        bool ComputeScore();
        float GetScore();
        HashSet<Card> GetCards();

        void Print();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class GameState
    {
        public static int indexCounter = 0;

        public int index = 0;

        public GameState previous;

        public int score;

        public Action action;

        public GameState(Action action, GameState previous = null)
        {
            this.action = action;

            index = indexCounter;
            indexCounter += 1;

            SimulateUseCard();
            ComputeScore();
        }

        public void SimulateUseCard()
        {
            if (action.type == MoveType.Attack)
            {
                SimulateHealthAfterAttack(action.attacker, action.target);
                SimulateHealthAfterAttack(action.target, action.attacker);
            }
        }

        public void SimulateHealthAfterAttack(Card attacker, Card target)
        {
            int health = 0;

            if (previous != null)
            {
                health = target.sHealth[previous.index];
            }
            else
            {
                health = target.defense;
            }

            if (!target.hasWard)
            {
                if (attacker.hasLethal)
                {
                    health = 0;
                }
                else
                {
                    health -= attacker.attack;
                }
            }

            target.sHealth.Add(index, Math.Max(0, health));
        }

        int ComputeScore()
        {
            this.score = ComputePlayerScore(Player.me) - ComputePlayerScore(Player.enemy);
                        
            return this.score;
        }

        int ComputePlayerScore(Player player)
        {
            int score = 0;

            foreach (var card in player.boardCards)
            {
                int cardHealth = card.defense;

                card.sHealth.TryGetValue(index, out cardHealth);

                if (cardHealth > 0)
                {
                    score += cardHealth;
                    score += card.attack;
                }
            }

            return score;
        }

        public static void CleanUp()
        {
            indexCounter = 0;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class Simulation
    {
        public static List<GameState> states = new List<GameState>();

        public static void Simulate()
        {
            GameState startState = new GameState(new Action());

            states.Add(startState);

            while(Timer.TickCount - Program.loopStartTime <= 800)
            {
                var ordered = states.OrderByDescending(state => state.score);

                var loopStartTime = Timer.TickCount;

                foreach (var state in ordered)
                {
                    SimulateNextBattle(state);
                }

                var total = Timer.TickCount - Program.loopStartTime;
                var loop = Timer.TickCount - loopStartTime;
                                
                Console.Error.WriteLine("Total: " + total + " Loop: " + loop);

                Debug();

                break;
            }
        }

        public static void Debug()
        {
            var ordered = states.OrderByDescending(state => state.score);

            var best = ordered.First();

            if (best.action.target != null)
            {
                Console.Error.WriteLine("Best : " + best.action.attacker.id + " vs " + best.action.target.id);
            }
        }

        public static void SimulateNextBattle(GameState state)
        {
            var enemyCards = Player.enemy.cards
                .OrderBy(c => c.hasGuard ? 0 : 1)
                .ThenBy(c => c.defense);

            foreach (var card in Player.me.boardCards.OrderBy(c => c.cost))
            {
                if (state.previous != null && card.sHealth[state.previous.index] <= 0)
                {
                    continue;
                }

                if (Player.enemy.numCardsOnBoard > 0 && card.attack > 0)
                {

                    foreach (var enemyCard in enemyCards)
                    {
                        var enemyHealth = state.previous != null ? enemyCard.sHealth[state.previous.index] : enemyCard.defense;

                        if (enemyHealth <= 0)
                        {
                            continue;
                        }


                        var action = new Action(MoveType.Attack, card, enemyCard);

                        var newSimulation = new GameState(action, state);

                        states.Add(newSimulation);
                    }
                }
            }
        }

        public static void CleanUp()
        {
            states = new List<GameState>();
        }
    }
}

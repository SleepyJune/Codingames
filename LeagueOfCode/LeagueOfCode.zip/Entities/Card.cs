﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    public enum CardLocation
    {
        PlayerHands = 0,
        PlayerBoard = 1,
        EnemyBoard = -1,
    }

    public enum CardType
    {
        Creature = 0,
        Green = 1,
        Red = 2,
        Blue = 3,
    }

    public enum Ability
    {
        Breakthrough,
        Charge,
        Drain,
        Guard,
        Lethal,
        Ward,
    }

    class Card
    {
        public int number;
        public int id;
        public CardLocation location;
        public CardType type;
        public int cost;
        public int attack;
        public int defense;
        public string abilities;
        public int myHealthChange;
        public int enemyHealthChange;
        public int cardDraw;

        public Dictionary<int, int> sHealth = new Dictionary<int, int>();
        public HashSet<int> simulationLostWard = new HashSet<int>();

        public bool hasBreakthrough;
        public bool hasCharge;
        public bool hasDrain;
        public bool hasGuard;
        public bool hasLethal;
        public bool hasWard;

        public void GetCardAbilities()
        {
            if (abilities[0] == 'B')
            {
                hasBreakthrough = true;
            }

            if (abilities[1] == 'C')
            {
                hasCharge = true;
            }

            if (abilities[2] == 'D')
            {
                hasDrain = true;
            }

            if (abilities[3] == 'G')
            {
                hasGuard = true;
            }

            if (abilities[4] == 'L')
            {
                hasLethal = true;
            }

            if (abilities[5] == 'W')
            {
                hasWard = true;
            }
        }
    }
}

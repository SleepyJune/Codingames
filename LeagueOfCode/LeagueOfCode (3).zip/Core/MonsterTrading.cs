﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class MonsterTrading
    {
        public static Dictionary<Card, List<Trade>> trades = new Dictionary<Card, List<Trade>>();
        public static List<AttackHero> heroAttacks = new List<AttackHero>();

        public static List<Simulation> allSimulations = new List<Simulation>();

        public static List<SimulationGroup> groupSimulations = new List<SimulationGroup>();

        public static void FindTrades()
        {
            var enemyCards = Player.enemy.cards
                .OrderBy(c => c.hasGuard ? 0 : 1)
                .ThenByDescending(c => c.health);

            foreach (var enemy in enemyCards)
            {
                if (enemy.health > 0)
                {
                    GetTradeOptions(enemy);
                }
            }
        }

        public static void FindAttackHeroCards()
        {
            for (int i = 0; i < Player.me.usableCards.Count; i++)
            {
                var card = Player.me.usableCards[i];
                var newAttack = new AttackHero(card);

                newAttack.ComputeScore();
                heroAttacks.Add(newAttack);

                allSimulations.Add(newAttack);
            }
        }

        public static void FindGroupSimulation()
        {
            FindTrades();
            FindAttackHeroCards();

            //allSimulations

            for (int i = 1; i < 4 && i < allSimulations.Count; i++)
            {
                int[] myCards = new int[i];
                GetSimulationCombination(myCards, 0, Player.me.usableCards.Count - 1, 0, i);
            }
        }

        public static void GetSimulationCombination(int[] data, int start, int end, int index, int numCards)
        {
            if (index == numCards)
            {
                SimulationGroup group = new SimulationGroup();
                string printString = "Group: ";
                for (int i = 0; i < numCards; i++)
                {
                    var sim = allSimulations[data[i]];
                    if (!group.AddSimulation(sim))
                    {
                        return;
                    }
                }

                var possible = group.ComputeScore();
                if (possible)
                {
                    foreach (var card in group.GetCards())
                    {
                        printString += card.id + " ";
                    }

                    printString += "Score: " + group.GetScore();

                    groupSimulations.Add(group);

                    Console.Error.WriteLine(printString);
                }

                return;
            }

            for (int i = start; i <= end && end - i + 1 >= numCards - index; i++)
            {
                data[index] = i;
                GetSimulationCombination(data, i + 1, end, index + 1, numCards);
            }
        }
        
        public static void GetTradeOptions(Card target)
        {
            for (int i = 1; i < 4 && i < Player.me.usableCards.Count; i++)
            {
                GetTradeOptionsHelper(target, i);
            }
        }

        public static void GetTradeOptionsHelper(Card target, int numCards)
        {
            int[] myCards = new int[numCards];
            GetTradeCombination(target, myCards, 0, Player.me.usableCards.Count-1, 0, numCards);
        }

        public static void GetTradeCombination(Card target, int[] data, int start, int end, int index, int numCards)
        {
            if (index == numCards)
            {
                Trade newTrade = new Trade(target);

                string printString = "Target: " + target.id + " Attackers: ";
                for(int i=0;i<numCards;i++)
                {
                    var card = Player.me.usableCards[data[i]];
                    newTrade.myCards.Add(card);

                    printString += card.id + " ";
                }
                                
                var killable = newTrade.ComputeScore();
                if (killable)
                {
                    printString += "Score: " + newTrade.GetScore();

                    AddTrade(target, newTrade);
                    //Console.Error.WriteLine(printString);
                }

                return;
            }

            for (int i = start; i <= end && end - i+1 >= numCards - index; i++)
            {
                data[index] = i;// Player.me.usableCards[i].id;
                GetTradeCombination(target, data, i + 1, end, index + 1, numCards);
            }
        }

        public static void AddTrade(Card target, Trade trade)
        {
            List<Trade> tradeList;
            if (trades.TryGetValue(target, out tradeList))
            {
                tradeList.Add(trade);
            }
            else
            {
                tradeList = new List<Trade>();
                tradeList.Add(trade);
                trades.Add(target, tradeList);
            }

            allSimulations.Add(trade);
        }

        public static void CleanUp()
        {
            trades = new Dictionary<Card, List<Trade>>();
            heroAttacks = new List<AttackHero>();
            allSimulations = new List<Simulation>();
            groupSimulations = new List<SimulationGroup>();
        }
    }
}

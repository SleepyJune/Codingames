﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class Strategy
    {
        public static List<Card> draftCards = new List<Card>();

        public static void Initialize()
        {
            Player.me.usableCards = Player.me.usableCards.OrderBy(c => c.id).ToList();
        }

        public static bool isDraftPhase
        {
            get
            {
                return Player.me.mana == 0;
            }
        }

        public static void MakeMove()
        {
            Initialize();

            if (isDraftPhase)
            {
                Draft();
            }
            else
            {
                Summon();
                UseItem();
                Attack();                
            }
        }

        public static void Summon()
        {
            foreach (var card in Player.me.handCards.OrderByDescending(c => c.cost))
            {
                if (Player.me.numCardsOnBoard >= 6)
                {
                    return;
                }

                if (card.type == CardType.Creature)
                {
                    if (Player.me.mana >= card.cost)
                    {
                        var newAction = new Action(card);
                        newAction.ApplyAction();
                    }
                }
            }
        }

        public static void UseItem()
        {
            foreach (var card in Player.me.handCards.OrderByDescending(c => c.cost))
            {
                if (card.type != CardType.Creature)
                {
                    if (Player.me.mana >= card.cost)
                    {
                        //Action.actions.Add(new Action(card));
                        if (card.type == CardType.Blue)
                        {
                            var newAction = new Action(MoveType.DirectUseItem, card, null);
                            newAction.ApplyAction();
                        }
                        else if (card.type == CardType.Green)
                        {
                            var target = Player.me.cards.OrderByDescending(c => c.location == CardLocation.PlayerBoard ? 0 : 1).FirstOrDefault();

                            if (target != null)
                            {
                                var newAction = new Action(MoveType.UseItem, card, target);
                                newAction.ApplyAction();
                            }
                        }
                        else if (card.type == CardType.Red)
                        {
                            var target = Player.enemy.cards.FirstOrDefault();

                            if (target != null)
                            {
                                var newAction = new Action(MoveType.UseItem, card, target);
                                newAction.ApplyAction();
                            }
                        }
                    }
                }
            }
        }

        public static void Attack()
        {
            var enemyCards = Player.enemy.cards
                .OrderBy(c => c.hasGuard ? 0 : 1)
                .ThenBy(c => c.health);

            /*foreach (var enemy in Player.enemy.boardCards.OrderByDescending(c => c.health))
            {
                if (enemy.health <= 0 || enemy.hasGuard == false)
                {
                    continue;
                }

                MonsterTrading.GetTradeOptions(enemy);

                List<Trade> tradeList;
                if (MonsterTrading.trades.TryGetValue(enemy, out tradeList))
                {
                    var orderedTrades = tradeList.OrderByDescending(t => t.GetScore());
                    var best = orderedTrades.FirstOrDefault();

                    if (best != null)
                    {
                        foreach (var card in best.myCards)
                        {
                            var newAction = new Action(MoveType.Attack, card, enemy);
                            newAction.ApplyAction();
                        }
                    }
                }
            }*/

            foreach (var card in Player.me.boardCards.OrderBy(c => c.cost))
            {
                if (Player.enemy.numCardsOnBoard > 0 && card.attack > 0 && card.used == false)
                {
                    foreach (var enemyCard in enemyCards)
                    {
                        //Action.actions.Add(new Action(card, enemyCard));

                        if (enemyCard.health <= 0)
                        {
                            continue;
                        }

                        if (enemyCard.hasGuard)
                        {
                            var newAction = new Action(MoveType.Attack, card, enemyCard);
                            newAction.ApplyAction();
                        }
                        else
                        {
                            var newAction = new Action(MoveType.DirectAttack, card, null);
                            newAction.ApplyAction();
                        }

                        break;
                    }
                }
                else
                {
                    var newAction = new Action(MoveType.DirectAttack, card, null);
                    newAction.ApplyAction();
                }
            }
        }

        public static void Draft()
        {
            Card card = draftCards.OrderBy(c => c.type == CardType.Creature ? 0 : 1).ThenBy(c => c.cost).First();

            int index = draftCards.IndexOf(card);

            var newAction = new Action(index);
            newAction.ApplyAction();
        }

        public static void CleanUp()
        {
            draftCards = new List<Card>();
        }
    }
}

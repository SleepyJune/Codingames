﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class AttackHero : Simulation
    {
        float score;
        public Card attacker;

        HashSet<Card> simulationCards;

        public AttackHero(Card attacker)
        {
            this.attacker = attacker;

            simulationCards = new HashSet<Card>();
            simulationCards.Add(attacker);
        }

        public bool ComputeScore()
        {
            //if taunt return false

            score = attacker.attack;

            return true;
        }

        public float GetScore()
        {
            return score;
        }

        public HashSet<Card> GetCards()
        {
            return simulationCards;
        }
    }
}

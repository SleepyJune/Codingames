﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class SimulationGroup : Simulation
    {
        List<Simulation> simulations;

        HashSet<Card> simulationCards;

        float score;

        public SimulationGroup()
        {
            simulations = new List<Simulation>();
        }

        public bool AddSimulation(Simulation sim)
        {
            if (simulationCards.Intersect(sim.GetCards()).Any())
            {
                return false;
            }

            simulations.Add(sim);

            foreach (var card in sim.GetCards())
            {
                simulationCards.Add(card);
            }

            score += sim.GetScore();

            return true;
        }

        public bool ComputeScore()
        {
            return true;
        }

        public float GetScore()
        {
            return score;
        }

        public HashSet<Card> GetCards()
        {
            return simulationCards;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class Trade : Simulation
    {
        public HashSet<Card> myCards = new HashSet<Card>();
        public Card target;

        public float myCost;
        public float enemyCost;

        float score = 0;

        public bool targetKilleable = false;
        public bool overkill = false;

        HashSet<Card> simulationCards;

        public Trade(Card target)
        {
            this.target = target;

            simulationCards = new HashSet<Card>();
            simulationCards.Add(target);
        }

        public void AddCard(Card card)
        {
            myCards.Add(card);
        }

        public bool ComputeScore()
        {
            myCost = 0;

            var targetHealth = target.health;

            var ordered = myCards.OrderByDescending(c => c.hasLethal).ThenByDescending(c=>c.attack).ToList();

            foreach (var card in ordered)
            {
                simulationCards.Add(card);

                if (targetHealth <= 0) //overkill
                {
                    overkill = true;
                    break;
                }

                if (card.hasLethal)
                {
                    targetHealth = 0;
                }
                else
                {
                    targetHealth -= card.attack;
                }

                var cardHealthLeft = card.health - target.attack;
                if (cardHealthLeft <= 0)
                {
                    myCost += card.health + card.attack;
                }
                else
                {
                    myCost += cardHealthLeft;
                }
            }

            enemyCost = target.health + target.attack;
            score = enemyCost - myCost;

            if (targetHealth <= 0 && overkill == false)
            {
                targetKilleable = true;
                return true;
            }
            else
            {
                return false;
            }
        }


        public float GetScore()
        {
            return score;
        }

        public HashSet<Card> GetCards()
        {
            return simulationCards;
        }
    }
}

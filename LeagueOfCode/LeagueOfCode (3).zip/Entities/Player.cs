﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class Player
    {
        public static Player me = new Player();
        public static Player enemy = new Player();

        public int health;
        public int mana;
        public int numCards;
        public int rune;

        public int numCardsOnBoard;

        public List<Card> cards = new List<Card>();
        public List<Card> boardCards = new List<Card>();
        public List<Card> handCards = new List<Card>();

        public List<Card> usableCards = new List<Card>();

        public static void CleanUp()
        {
            for (int i = 0; i < 2; i++)
            {
                Player player;
                if (i == 0)
                {
                    player = me;
                }
                else
                {
                    player = enemy;
                }
                                
                player.cards = new List<Card>();
                player.boardCards = new List<Card>();
                player.handCards = new List<Card>();
                player.usableCards = new List<Card>();
                player.numCardsOnBoard = 0;
            }
        }
    }
}

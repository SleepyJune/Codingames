﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class MonsterTrading
    {
        public static void StartSimulation()
        {
            var start = Timer.TickCount;

            FindGroupSimulation(Player.enemy);
            Console.Error.WriteLine("Enemy Trade Groups: " + Player.enemy.tradeGroups.Count);
            
            FindGroupSimulation(Player.me);
            Console.Error.WriteLine("My Trade Groups: " + Player.me.tradeGroups.Count);
                        
            FindMyBestTradeGroup();

            Console.Error.WriteLine("End Simulation: " + (Timer.TickCount - start));
        }

        public static void FindMyBestTradeGroup()
        {
            foreach (var myGroup in Player.me.tradeGroups)
            {


                var best = Player.enemy.tradeGroups.Where(group => PossibleGroupSelection(myGroup, group))
                                                   .OrderByDescending(group => group.GetScore()).FirstOrDefault();

                if (best != null)
                {
                    myGroup.finalScore = myGroup.GetScore() - best.GetScore();
                }
                else
                {
                    myGroup.finalScore = myGroup.GetScore();
                }
            }
        }

        public static bool PossibleGroupSelection(SimulationGroup myGroup, SimulationGroup enemyGroup)
        {
            foreach (var target in myGroup.targets)
            {
                if (enemyGroup.simulationCards.Contains(target))
                {
                    return false;
                }
            }

            return true;
        }

        public static void FindGroupSimulation(Player player)
        {           
            FindTrades(player);

            //player.trades = player.trades.OrderBy(sim => sim is Trade ? 0 : 1).ToList();

            for (int i = 1; i <= 3 && i <= player.trades.Count; i++)
            {
                int[] myCards = new int[i];
                GetSimulationCombination(player, myCards, 0, player.trades.Count - 1, 0, i);
            }
        }

        public static void GetSimulationCombination(Player player, int[] data, int start, int end, int index, int numCards)
        {
            if (index == numCards)
            {
                SimulationGroup group = new SimulationGroup(player);
                                
                for (int i = 0; i < numCards; i++)
                {
                    var sim = player.trades[data[i]];
                    if (!group.AddSimulation(sim))
                    {
                        return;
                    }
                }

                var possible = group.ComputeScore();
                if (possible)
                {
                    player.tradeGroups.Add(group);

                    //Console.Error.WriteLine(printString);
                }

                return;
            }

            for (int i = start; i <= end && end - i + 1 >= numCards - index; i++)
            {
                data[index] = i;
                GetSimulationCombination(player, data, i + 1, end, index + 1, numCards);
            }
        }

        public static void FindTrades(Player player)
        {
            var enemyPlayer = player.isMe ? Player.enemy : Player.me;

            var enemyCards = enemyPlayer.boardCards
                .OrderBy(c => c.hasGuard ? 0 : 1)
                .ThenByDescending(c => c.health);

            var print = player.isMe ? "My " : "Enemy ";
            print += "Useable Cards: ";

            foreach(var card in player.usableCards)
            {
                print += card.id + " ";
            }

            Console.Error.WriteLine(print);

            foreach (var enemy in enemyCards)
            {
                if (enemy.health > 0 && (enemy.attack > 0 || enemy.hasGuard))
                {                    
                    GetTradeOptions(player, enemy);
                }
            }
        }

        public static void GetTradeOptions(Player player, Card target)
        {
            for (int i = 1; i < 4 && i <= player.usableCards.Count; i++)
            {
                GetTradeOptionsHelper(player, target, i);
            }
        }

        public static void GetTradeOptionsHelper(Player player, Card target, int numCards)
        {
            int[] myCards = new int[numCards];
            GetTradeCombination(player, target, myCards, 0, player.usableCards.Count-1, 0, numCards);
        }

        public static void GetTradeCombination(Player player, Card target, int[] data, int start, int end, int index, int numCards)
        {
            if (index == numCards)
            {
                Trade newTrade = new Trade(target);
                                
                for(int i=0;i<numCards;i++)
                {
                    var card = player.usableCards[data[i]];
                    newTrade.AddCard(card);                    
                }
                                
                var killable = newTrade.ComputeScore();
                if (killable)
                {
                    player.trades.Add(newTrade);

                    //newTrade.Print();
                }

                return;
            }

            for (int i = start; i <= end && end - i+1 >= numCards - index; i++)
            {
                data[index] = i;
                GetTradeCombination(player, target, data, i + 1, end, index + 1, numCards);
            }
        }

        public static void CleanUp()
        {
            
        }
    }
}

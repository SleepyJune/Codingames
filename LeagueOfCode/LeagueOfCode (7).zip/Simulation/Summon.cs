﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class SummonGroup
    {
        public Trade trade;

        public List<Card> myCards = new List<Card>();

        public int simulatedManaCost = 0;

        public float score;

        public int numSummons;

        public SummonGroup(Trade trade)
        {
            this.trade = trade;

            simulatedManaCost = trade.simulatedManaCost;
            numSummons = trade.numSummons;
        }

        public bool AddCard(Card card)
        {
            if (trade.GetCards().Contains(card)) //already summoned
            {
                return false;
            }

            if (Player.me.boardCards.Count + numSummons >= 6)
            {
                return false; //max summons on field
            }

            simulatedManaCost += card.cost;

            if (simulatedManaCost > Player.me.mana)
            {
                return false;
            }

            numSummons += 1;
            myCards.Add(card);

            score += card.cardValue - card.cost * 2;

            return true;
        }

        public void Print()
        {
            string printString = "SummonGroup: ";

            foreach (var card in myCards)
            {
                printString += card.id + " ";
            }

            printString += "Score: " + score;

            Console.Error.WriteLine(printString);
        }

        public static void GetSummons(Trade trade)
        {
            var summons = Player.me.handCards.Where(c=> c.location == CardLocation.PlayerHands && c.type == CardType.Creature).ToList();

            for (int i = 1; i <= summons.Count; i++)
            {
                GetSummonsHelper(summons, trade, i);
            }
        }

        public static void GetSummonsHelper(List<Card> summons, Trade trade, int numCards)
        {
            int[] myCards = new int[numCards];
            GetSummonsCombination(summons, trade, myCards, 0, summons.Count - 1, 0, numCards);
        }

        public static void GetSummonsCombination(List<Card> summons, Trade trade, int[] data, int start, int end, int index, int numCards)
        {
            if (index == numCards)
            {
                SummonGroup newSummonGroup = new SummonGroup(trade);

                for (int i = 0; i < numCards; i++)
                {
                    var card = summons[data[i]];
                    if (!newSummonGroup.AddCard(card))
                    {
                        return; //cannot summon
                    }
                }

                newSummonGroup.Print();

                return;
            }

            for (int i = start; i <= end && end - i + 1 >= numCards - index; i++)
            {
                data[index] = i;
                GetSummonsCombination(summons, trade, data, i + 1, end, index + 1, numCards);
            }
        }
    }
}

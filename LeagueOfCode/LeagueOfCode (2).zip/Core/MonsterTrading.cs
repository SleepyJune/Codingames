﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeagueOfCode
{
    class MonsterTrading
    {
        public static List<Trade> trades = new List<Trade>();

        public static void FindTrades()
        {
            Player.me.usableCards = Player.me.usableCards.OrderBy(c => c.id).ToList();

            var enemyCards = Player.enemy.cards
                .OrderBy(c => c.hasGuard ? 0 : 1)
                .ThenByDescending(c => c.health);

            foreach (var enemy in enemyCards)
            {
                if (enemy.health > 0)
                {
                    //var myCards = Player.me.usableCards.OrderByDescending(c => c.cost);

                    GetTradeOptions(enemy);
                }
            }
        }

        public static void GetTradeOptionsOld(Card target)
        {
            int numCards = 1;

            bool foundTrade = true;
            bool foundAtleastOne = true;
            
            while (foundAtleastOne)
            {
                foundAtleastOne = false;

                while (foundTrade)
                {
                    Trade newTrade = new Trade(target);

                    //foundTrade = GetTradePartners(newTrade, numCards);
                    
                    if (foundTrade)
                    {
                        //
                        Console.Error.WriteLine(newTrade.target.id);
                        trades.Add(newTrade);
                        foundAtleastOne = true;
                    }
                }

                var orderedTrades = trades.OrderByDescending(t => t.score);
                var best = orderedTrades.FirstOrDefault();

                if (best != null)
                {
                    Console.Error.WriteLine(best.myCards.First().id + " attack " + best.target.id);
                }

                numCards += 1;
                break;
            }
        }

        public static void GetTradeOptions(Card target)
        {
            for (int i = 1; i < 4 && i < Player.me.usableCards.Count; i++)
            {
                GetTradeOptionsHelper(target, i);
            }
        }

        public static void GetTradeOptionsHelper(Card target, int numCards)
        {
            int[] myCards = new int[numCards];
            GetTradeCombination(target, myCards, 0, Player.me.usableCards.Count-1, 0, numCards);
        }

        public static void GetTradeCombination(Card target, int[] data, int start, int end, int index, int numCards)
        {
            if (index == numCards)
            {
                Trade newTrade = new Trade(target);

                string printString = "Target: " + target.id + " Attackers: ";
                for(int i=0;i<numCards;i++)
                {
                    var card = Player.me.usableCards[data[i]];
                    newTrade.myCards.Add(card);

                    printString += card.id + " ";
                }
                                
                var killable = newTrade.ComputeScore();
                if (killable)
                {
                    printString += "Score: " + newTrade.score;

                    trades.Add(newTrade);
                    Console.Error.WriteLine(printString);
                }

                return;
            }

            for (int i = start; i <= end && end - i+1 >= numCards - index; i++)
            {
                data[index] = i;// Player.me.usableCards[i].id;
                GetTradeCombination(target, data, i + 1, end, index + 1, numCards);
            }
        }

        public static bool GetTradePartners(Trade trade, int numCards)
        {
            bool foundCard = false;

            foreach (var card in Player.me.usableCards)
            {
                if (trade.myCards.Contains(card))
                {
                    continue;
                }

                trade.myCards.Add(card);
                foundCard = true;
                break;
            }

            if (foundCard)
            {
                trade.ComputeScore();
                if (trade.score < 0)
                {

                }
            }

            if (foundCard && trade.myCards.Count < numCards)
            {
                return GetTradePartners(trade, numCards);
            }
            else
            {
                return foundCard;
            }            
        }

        public static void CleanUp()
        {
            trades = new List<Trade>();
        }
    }
}

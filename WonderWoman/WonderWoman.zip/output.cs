
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WonderWoman
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] inputs;
            int size = int.Parse(Console.ReadLine());
            int unitsPerPlayer = int.Parse(Console.ReadLine());

            // game loop
            while (true)
            {
                for (int i = 0; i < size; i++)
                {
                    string row = Console.ReadLine();
                }
                for (int i = 0; i < unitsPerPlayer; i++)
                {
                    inputs = Console.ReadLine().Split(' ');
                    int unitX = int.Parse(inputs[0]);
                    int unitY = int.Parse(inputs[1]);

                    var unit = new Unit(unitX, unitY, Team.ally);
                    Unit.units.Add(unit);
                }
                for (int i = 0; i < unitsPerPlayer; i++)
                {
                    inputs = Console.ReadLine().Split(' ');
                    int otherX = int.Parse(inputs[0]);
                    int otherY = int.Parse(inputs[1]);

                    var unit = new Unit(otherX, otherY, Team.enemy);
                    Unit.units.Add(unit);
                }
                int legalActions = int.Parse(Console.ReadLine());
                for (int i = 0; i < legalActions; i++)
                {
                    var action = new Action(Console.ReadLine());
                    action.unit.actions.Add(action);
                }

                //Game.InitializeTurn();
                Game.MakeMove();
                Game.PrintActions();
                Game.CleanUp();                
            }
        }
    }

    class Game
    {
        public static int gameTurn = 0;

        public static void MakeMove()
        {
            Strategy.MakeMove();
        }

        public static void PrintActions()
        {
            Action.PrintActions();
        }

        public static void CleanUp()
        {
            Unit.CleanUp();
            Action.CleanUp();

            gameTurn++;
        }
    }

    class Strategy
    {
        public static void MakeMove()
        {
            foreach (var unit in Unit.units)
            {
                if (unit.team == Team.ally)
                {
                    Action.AddAction(unit.actions.FirstOrDefault());
                }
            }
        }
    }

    enum Team
    {
        ally,
        enemy
    }

    class Unit
    {
        public static List<Unit> units = new List<Unit>();
        
        public int x;
        public int y;
        public Team team;

        public int index;

        public List<Action> actions = new List<Action>();

        public Unit(int x, int y, Team team)
        {
            this.x = x;
            this.y = y;
            this.team = team;

            this.index = units.Count;
        }

        public static void CleanUp()
        {
            units = new List<Unit>();
        }
    }

    enum ActionType
    {
        MoveAndBuild
    }

    enum Direction
    {
        N,
        NE,
        E,
        SE,
        S,
        SW,
        W,
        NW
    }

    class Action
    {
        public static List<Action> actions = new List<Action>();

        public ActionType type;
        public Unit unit;
        public Direction dir1;
        public Direction dir2;
        
        public Action()
        {
            
        }

        public Action(ActionType type, Unit unit, Direction dir1, Direction dir2)
        {
            this.type = type;
            this.unit = unit;
            this.dir1 = dir1;
            this.dir2 = dir2;
        }

        public Action(string str)
        {
            var inputs = str.Split(' ');

            string atype = inputs[0];
            int index = int.Parse(inputs[1]);
            string dir1 = inputs[2];
            string dir2 = inputs[3];

            this.type = ActionType.MoveAndBuild;
            this.unit = Unit.units[index];
                        
            foreach (Direction direction in Enum.GetValues(typeof(Direction)))
            {
                if (direction.ToString() == dir1)
                {
                    this.dir1 = direction;
                }

                if (direction.ToString() == dir2)
                {
                    this.dir2 = direction;
                }
            }

        }

        public static void AddAction(Action action)
        {            
            Action.actions.Add(action);
        }

        public static void CleanUp()
        {
            actions = new List<Action>();
        }

        public static void PrintActions()
        {
            string str = "";

            foreach (var action in actions)
            {
                if (action.type == ActionType.MoveAndBuild)
                {
                    str += "MOVE&BUILD " + action.unit.index + " " + action.dir1.ToString() + " " + action.dir2.ToString();
                }
            }

            Console.WriteLine(str);
        }
    }

    class Timer
    {
        private static DateTime loadTime = DateTime.Now;

        public static float TickCount
        {
            get
            {
                return (int)DateTime.Now.Subtract(loadTime).TotalMilliseconds;
            }
        }
    }




}

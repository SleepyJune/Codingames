﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WonderWoman
{
    class Strategy
    {
        public static void MakeMove()
        {
            foreach (var unit in Unit.units)
            {
                if (unit.team == Team.ally)
                {
                    Action.AddAction(unit.actions.FirstOrDefault());
                }
            }
        }
    }
}

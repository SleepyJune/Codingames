﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WonderWoman
{
    enum Team
    {
        ally,
        enemy
    }

    class Unit
    {
        public static List<Unit> units = new List<Unit>();
        
        public int x;
        public int y;
        public Team team;

        public int index;

        public List<Action> actions = new List<Action>();

        public Unit(int x, int y, Team team)
        {
            this.x = x;
            this.y = y;
            this.team = team;

            this.index = units.Count;
        }

        public static void CleanUp()
        {
            units = new List<Unit>();
        }
    }
}

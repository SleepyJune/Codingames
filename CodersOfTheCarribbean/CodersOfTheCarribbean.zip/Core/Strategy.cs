﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class Strategy
    {
        public static Random random = new Random();

        public static void ShipMakeMove(Ship ship)
        {
            foreach (var cannon in Cannon.cannons)
            {
                if (cannon.pos.Distance(ship.pos) <= 1)
                {
                    int randX = random.Next(0, 22);
                    int randY = random.Next(0, 20);

                    Vector randomPos = new Vector(randX, randY);

                    var action = new Action(MoveType.Move, ship, randomPos);
                    Action.AddAction(action);

                    Console.Error.WriteLine("Dodging");
                    return;
                }
            }

            if (ship.firedLastRound == true || ship.pos.Distance(ship.lastMoveCommand) < 3)
            //|| (random.Next(0, 2) == 1))
            {
                foreach (var barrel in Barrel.barrels.OrderBy(b => ship.pos.Distance(b.pos)))
                {
                    var action = new Action(MoveType.Move, ship, barrel.pos);
                    Action.AddAction(action);
                    return;
                }
            }
            else
            {
                foreach (var enemy in Ship.ships.Values.OrderBy(s => ship.pos.Distance(s.pos)))
                {
                    if (enemy.team == Team.Enemy && enemy.isAlive)
                    {
                        //Console.Error.WriteLine("ATK " + enemy.id + ":" + enemy.pos.toStr());

                        var distance = ship.pos.Distance(enemy.pos);
                        var turns = distance / 3 + 1;
                        var predictedPos = enemy.pos + enemy.direction * turns;// *enemy.speed;

                        if (enemy.pos == enemy.prevPos || !predictedPos.isInBound())
                        {
                            predictedPos = enemy.pos;
                        }

                        var action = new Action(MoveType.Fire, ship, predictedPos.Round());
                        Action.AddAction(action);
                        return;
                    }
                }
            }

            Action.AddAction(new Action());
        }

        public static void MakeMove()
        {
            foreach (var ship in Ship.ships.Values)
            {                
                if (ship.team == Team.Ally && ship.isAlive)
                {
                    ShipMakeMove(ship);                    
                }
            }
        }
    }
}

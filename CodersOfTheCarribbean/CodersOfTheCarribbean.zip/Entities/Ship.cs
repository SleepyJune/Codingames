﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class Ship : Entity, IEquatable<Ship>
    {
        public static Dictionary<int, Ship> ships = new Dictionary<int, Ship>();

        public int id;
        
        public int speed;
        public int rotation;
        public int rum;

        public bool isAlive = true;

        public Vector prevPos;
        public Vector direction;
        
        public Vector lastMoveCommand;

        public bool firedLastRound;

        public int x, y;


        public Ship(int id)
        {
            this.id = id;
        }

        public static void CleanUp()
        {
            foreach (var ship in ships.Values)
            {
                ship.isAlive = false;
            }
        }

        public override void ProcessMessage(EntityMessage message)
        {
            this.prevPos = pos;
            
            this.pos = new Vector(message.x, message.y);
            this.rotation = message.arg1;
            this.speed = message.arg2;
            this.rum = message.arg3;
            this.isAlive = true;

            this.x = message.x;
            this.y = message.y;

            this.direction = this.pos.Direction(prevPos);

            if (message.arg4 == 1)
            {
                this.team = Team.Ally;
            }
            else
            {
                this.team = Team.Enemy;
            }            
        }

        public static Ship GetShipByID(int id)
        {
            Ship ship;
            if (Ship.ships.TryGetValue(id, out ship))
            {
                return ship;
            }
            else
            {
                ship = new Ship(id);
                ships.Add(id, ship);
                return ship;
            }
        }

        public override bool Equals(object obj)
        {
            if (obj is Ship)
            {
                return Equals((Ship)this);
            }

            return false;
        }

        public bool Equals(Ship ship)
        {
            return ship.id == this.id;
        }
    }
}

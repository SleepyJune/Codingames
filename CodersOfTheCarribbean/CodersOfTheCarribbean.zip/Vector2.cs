﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    public struct Vector: IEquatable<Vector>
    {
        public double x;
        public double y;

        public Vector(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public static Vector Zero
        {
            get { return new Vector(0f, 0f); }
        }

        public static bool operator ==(Vector value1, Vector value2)
        {
            return value1.x == value2.x && value1.y == value2.y;
        }


        public static bool operator !=(Vector value1, Vector value2)
        {
            return value1.x != value2.x || value1.y != value2.y;
        }

        public static Vector operator *(Vector value, double scaleFactor)
        {
            value.x *= scaleFactor;
            value.y *= scaleFactor;
            return value;
        }

        public static Vector operator +(Vector value1, Vector value2)
        {
            value1.x += value2.x;
            value1.y += value2.y;
            return value1;
        }


        public static Vector operator -(Vector value1, Vector value2)
        {
            value1.x -= value2.x;
            value1.y -= value2.y;
            return value1;
        }

        public override bool Equals(object obj)
        {
            if (obj is Vector)
            {
                return Equals((Vector)this);
            }

            return false;
        }

        public bool Equals(Vector other)
        {
            return (x == other.x) && (y == other.y);
        }

        public override int GetHashCode()
        {
            return x.GetHashCode() + y.GetHashCode();
        }
    }

    public static class VectorExtensions
    {
        public static double Distance(this Vector value1, Vector value2)
        {
            double v1 = value1.x - value2.x, v2 = value1.y - value2.y;
            return (double)Math.Sqrt((v1 * v1) + (v2 * v2));
        }

        public static double Dot(this Vector value1, Vector value2)
        {
            return (value1.x * value2.x) + (value1.y * value2.y);
        }

        public static Vector Normalized(this Vector value)
        {
            double val = 1.0f / (double)Math.Sqrt((value.x * value.x) + (value.y * value.y));
            value.x *= val;
            value.y *= val;
            return value;
        }

        public static Vector Direction(this Vector current, Vector previous)
        {
            return (current - previous).Normalized();
        }

        public static Vector Round(this Vector vec)
        {
            return new Vector(Math.Round(vec.x), Math.Round(vec.y));
        }

        public static bool isInBound(this Vector vec)
        {
            if (vec.x < 0 || vec.x > 22 || vec.y < 0 || vec.y > 20)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static string toStr(this Vector vec)
        {
            return "(" + vec.x + " " + vec.y + ")";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    public struct Hex
    {
        public int col;
        public int row;

        public Hex(int column, int row)
        {
            this.col = column;
            this.row = row;
        }
    }

    public static class HexExtensions
    {
        public static Vector ConvertCube(this Hex hex)
        {
            double x = hex.col - (hex.row - (hex.row & 1)) / 2;
            double z = hex.row;
            double y = -x - z;

            return new Vector(x, y, z);
        }

        public static bool isInBound(this Hex hex)
        {
            return !(hex.col < 0 || hex.col > 22 || hex.row < 0 || hex.row > 20);
        }

        public static string toStr(this Hex hex)
        {
            return "(" + hex.col + " " + hex.row + ")";
        }
    }
}

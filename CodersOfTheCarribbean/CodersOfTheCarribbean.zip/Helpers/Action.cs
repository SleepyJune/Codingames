﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    public enum MoveType
    {
        Wait,
        Move,
        Fire,
    }

    class Action
    {
        public static List<Action> actions = new List<Action>();

        public MoveType move;
        public Vector position;
        public Ship ship;

        public Action()
        {
            this.move = MoveType.Wait;
        }

        public Action(MoveType move, Ship ship, Vector position)
        {
            this.move = move;
            this.position = position;
            this.ship = ship;
        }

        public static void CleanUp()
        {
            actions = new List<Action>();
        }

        public static void AddAction(Action action)
        {
            if (action.move == MoveType.Move)
            {
                action.ship.firedLastRound = false;
                action.ship.lastMoveCommand = action.position;
            }
            else if (action.move == MoveType.Fire)
            {
                action.ship.firedLastRound = true;
            }

            Action.actions.Add(action);
        }

        public static void PrintActions()
        {
            if (actions.Count == 0)
            {
                Console.WriteLine("WAIT");
                return;
            }

            string str = "";//"WAIT;";
                        
            foreach (var action in actions)
            {
                switch (action.move)
                {
                    case MoveType.Move:
                        str = "MOVE " + action.position.x + " " + action.position.y;
                        break;
                    case MoveType.Fire:
                        str = "FIRE " + action.position.x + " " + action.position.y;
                        break;
                    default:
                        str = "WAIT";
                        break;
                }

                Console.WriteLine(str);
            }

            //str = str.Remove(str.Length - 1); //remove extra ;

            
        }

    }
}

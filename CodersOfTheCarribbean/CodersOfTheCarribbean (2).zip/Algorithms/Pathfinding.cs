﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class Pathfinding
    {
        public static PathInfo CalculateShortestPaths(Ship start)
        {
            Dictionary<Vector, int> dist = new Dictionary<Vector, int>();
            Dictionary<Vector, Vector> prev = new Dictionary<Vector, Vector>();

            HashSet<Vector> q = new HashSet<Vector>();

            for (int x = 0; x < 23; x++)
            {
                for (int y = 0; y < 21; y++)
                {
                    Vector pos = (new Hex(x, y)).ConvertCube();

                    dist.Add(pos, 999);
                    prev.Add(pos, Vector.Undefined);

                    q.Add(pos);
                }
            }
                        
            dist[start.pos] = 0;

            while (q.Count > 0)
            {
                Vector current = q.OrderBy(v => dist[v]).First();
                q.Remove(current);

                foreach (Vector dir in Vector.directions)
                {
                    var pos = current + dir;

                    int alternativeDistance = dist[current] + 1;
                    if (isPositionSafe(start, pos) && alternativeDistance < dist[pos])
                    {
                        dist[pos] = alternativeDistance;
                        prev[pos] = current;
                    }
                }
            }

            return new PathInfo(start, dist, prev);
        }

        public static PositionNode UseBFS(Vector start, Vector end, Ship ship)
        {
            //BFS start

            HashSet<Vector> set = new HashSet<Vector>();
            Queue<PositionNode> q = new Queue<PositionNode>();

            q.Enqueue(new PositionNode(start));

            PositionNode current = null;

            int count = 0;

            // bfs loop
            while (q.Count != 0)
            {
                current = q.Dequeue();

                count++;

                if (count % 100 == 0)
                {
                    Console.Error.WriteLine(count);
                }

                //Console.Error.WriteLine(current.pos.ConvertHex().toStr());

                if (current.pos == end)
                {
                    //Console.Error.WriteLine("Found exit: " + current.index);
                    break;
                }

                foreach (Vector dir in Vector.directions)
                {
                    var pos = current.pos + dir;

                    if (!isPositionSafe(ship, pos))
                    {
                        set.Add(pos);
                        continue;
                    }

                    if (!set.Contains(pos))
                    {                        
                        set.Add(pos);
                        
                        PositionNode node = new PositionNode(pos);
                        node.parent = current;
                        
                        q.Enqueue(node);
                    }
                }
            }

            return current.parent;
        }

        public static bool isPositionSafe(Ship ship, Vector pos)
        {
            if (!pos.ConvertHex().isInBound() || ship.pos.Distance(pos) > 20)
            {
                return false;
            }

            foreach (var mine in Mine.mines)
            {
                if (mine.pos == pos)
                {
                    return false;
                }
            }

            foreach (var cannon in Cannon.cannons)
            {
                if (cannon.pos == pos)
                {
                    return false;
                }
            }

            foreach (var s in Ship.ships.Values)
            {
                if (ship != s)
                {
                    if(s.nextPositionInfo.shipFront == pos
                    || s.nextPositionInfo.pos == pos
                    || s.nextPositionInfo.shipBack == pos)
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class PathInfo
    {
        public Dictionary<Vector, int> dist = new Dictionary<Vector, int>();
        public Dictionary<Vector, Vector> prev = new Dictionary<Vector, Vector>();

        public Ship ship;

        public PathInfo(Ship ship, Dictionary<Vector, int> dist, Dictionary<Vector, Vector> prev)
        {
            this.ship = ship;

            this.dist = dist;
            this.prev = prev;
        }

        public Vector GetNextStep(Vector target)
        {
            Vector current = prev[target];
            int count = 0;
            while (current != Vector.Undefined)
            {
                count++;
                if (count % 100 == 0)
                {                    
                    Console.Error.WriteLine(count);
                }

                if (prev[current] == ship.pos)
                {
                    break;
                }
                current = prev[current];
            }

            return current;
        }
    }
}

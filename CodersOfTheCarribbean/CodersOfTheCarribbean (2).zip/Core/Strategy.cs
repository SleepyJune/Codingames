﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class Strategy
    {
        public static Random random = new Random();

        public static void ShipMakeMove(Ship ship)
        {
            

            /*foreach (var cannon in Cannon.cannons)
            {
                var shipPredictedPos = ship.GetPredictedPos(cannon.turns);

                if (cannon.pos.Distance(shipPredictedPos) <= 2)
                {
                    if (ship.speed == 0 && ship.lastMoveCommand.Distance(ship.pos) > 4)
                    {
                        var action = new Action(MoveType.Faster, ship);
                        Action.AddAction(action);
                        return;
                    }
                    else
                    {
                        int randX = random.Next(0, 22);
                        int randY = random.Next(0, 20);

                        Hex hex = new Hex(randX, randY);

                        Vector randomPos = hex.ConvertCube();

                        var action = new Action(MoveType.Move, ship, randomPos);
                        Action.AddAction(action);

                        Console.Error.WriteLine("Dodging");
                        return;
                    }
                }
            }*/

            if (false)//ship.firedLastRound == false)
            {
                foreach (var enemy in Ship.ships.Values.OrderBy(s => ship.pos.Distance(s.pos)))
                {
                    if (enemy.team == Team.Enemy && enemy.isAlive)
                    {
                        //Console.Error.WriteLine("ATK " + enemy.id + ":" + enemy.pos.toStr());

                        var predictedPos = ship.GetPredictedFirePos(enemy);

                        if (predictedPos.Distance(ship.pos) <= 21)
                        {
                            var action = new Action(MoveType.Fire, ship, predictedPos);
                            Action.AddAction(action);
                            return;
                        }
                    }
                }
            }
            else
            {
                foreach (var barrel in Barrel.barrels.OrderBy(b => ship.pos.Distance(b.pos)))
                {
                    //ship.targetPosition = barrel.pos;

                    /*var targetPos = barrel.pos;
                    if (barrel.pos.Distance(ship.pos) > 20)
                    {
                        var dir = (targetPos - ship.pos).Normalized();
                        targetPos = ship.pos + dir * 15;
                    }*/

                    //var path = ship.paths.prev
                    
                    
                    var nextPos = ship.paths.GetNextStep(barrel.pos);
                    if (nextPos != Vector.Undefined)
                    {
                        if (nextPos == ship.nextPositionInfo.shipRight)
                        {
                            var action = new Action(MoveType.Right, ship);
                            Action.AddAction(action);
                            return;
                        }
                        else if (nextPos == ship.nextPositionInfo.shipLeft)
                        {
                            var action = new Action(MoveType.Left, ship);
                            Action.AddAction(action);
                            return;
                        }
                        else if (nextPos == ship.currentPositionInfo.shipFront)
                        {
                            var action = new Action(MoveType.Faster, ship);
                            Action.AddAction(action);
                            return;
                        }
                        /*else if (path.parent.parent != null && 
                            path.parent.parent == ship.shipFront && ship.speed == 0)
                        {
                            var action = new Action(MoveType.Faster, ship);
                            Action.AddAction(action);
                            return;
                        }
                        else
                        {
                            var action = new Action(MoveType.Move, ship, path.parent.pos);
                            Action.AddAction(action);
                            return;
                        }*/                        
                    }
                }

                /*foreach (var ally in Ship.ships.Values)
                {
                    if (ally.team == Team.Ally && ally.isAlive && ally != ship)
                    {
                        //int randX = random.Next(0, 10);
                        //int randY = random.Next(0, 10);

                        Console.Error.WriteLine("Going to ally: " + ally.id);

                        var action = new Action(MoveType.Move, ship, ally.pos);
                        Action.AddAction(action);
                        return;
                    }
                }*/
            }

            Action.AddAction(new Action(ship));
        }

        public static void MakeMove()
        {
            foreach (var ship in Ship.ships.Values)
            {                
                if (ship.team == Team.Ally && ship.isAlive)
                {
                    ShipMakeMove(ship);                    
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class PathInfo
    {
        public Dictionary<PositionNode, int> dist = new Dictionary<PositionNode, int>();
        public Dictionary<PositionNode, PositionNode> prev = new Dictionary<PositionNode, PositionNode>();

        public Dictionary<Vector, List<PositionNode>> pathTable = new Dictionary<Vector, List<PositionNode>>();

        public Ship ship;

        public PathInfo(Ship ship, Dictionary<PositionNode, int> dist, Dictionary<PositionNode, PositionNode> prev)
        {
            this.ship = ship;

            this.dist = dist;
            this.prev = prev;
        }

        public PositionNode GetNextStep(Vector target)
        {
            List<PositionNode> pathList;

            if (pathTable.TryGetValue(target, out pathList))
            {
                foreach (var node in pathList.OrderBy(n=>n.step))
                {
                    PositionNode current = node;

                    while (current.parent != null && current.parent.pos != ship.pos)
                    {
                        current = current.parent;    
                    }

                    if (current != null)
                    {
                        return current;
                    }
                }
            }

            return null;
        }

        /*public List<Vector> GetNextStep(Vector target)
        {
            List<Vector> ret = new List<Vector>();
            Vector current = target;

            /*while (prev.ContainsKey(current))
            {
                //Console.Error.WriteLine("Track: " + current.toStr());

                ret.Add(current);

                if (prev[current] == ship.pos)
                {
                    break;
                }
                current = prev[current];
            }

            ret.Reverse();
            return ret;
        }*/
    }
}

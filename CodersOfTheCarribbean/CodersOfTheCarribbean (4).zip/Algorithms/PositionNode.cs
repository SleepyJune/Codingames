﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class PositionNode : IEquatable<PositionNode>
    {
        public Vector pos;
        public int rotation;
        public int prevRotation;
        public int speed;

        public MoveType moveType;

        public int step = 0;

        public List<PositionNode> neighbours = new List<PositionNode>();

        public PositionNode parent;

        public PositionNode(Vector pos, MoveType moveType, int rotation, int prevRotation, int speed, int step)
        {
            this.pos = pos;
            this.rotation = rotation;
            this.speed = speed;
            this.moveType = moveType;
            this.prevRotation = prevRotation;
            this.step = step;
        }

        public override bool Equals(object obj)
        {
            if (obj is PositionNode)
            {
                return Equals((PositionNode)this);
            }

            return false;
        }

        public bool Equals(PositionNode node)
        {
            return node.pos == this.pos && node.moveType == this.moveType;
        }

        public override int GetHashCode()
        {
            return (int)this.moveType * 100 * 100 + this.pos.GetHashCode();
        }
    }
}

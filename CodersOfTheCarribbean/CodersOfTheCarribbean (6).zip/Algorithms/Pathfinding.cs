﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class Pathfinding
    {
        public static void InitializeShortestPaths(PathInfo pathInfo)
        {
            var ship = pathInfo.ship;
            var dist = pathInfo.dist;
            var prev = pathInfo.prev;

            HashSet<PositionNode> set = new HashSet<PositionNode>();
            Queue<PositionNode> q = new Queue<PositionNode>();

            int step = 0;
            List<PositionNode> nextExpand = new List<PositionNode>();
            
            PositionNode shipNode = new PositionNode(ship.pos, MoveType.Wait, ship.rotation, ship.rotation, ship.speed, step);
            q.Enqueue(shipNode);

            dist.Add(shipNode,0);
            prev.Add(shipNode, null);

            shipNode.distance = 0;

            PositionNode current;

            while (q.Count > 0)
            {
                current = q.Dequeue();
                
                foreach (MoveType move in Enum.GetValues(typeof(MoveType)))
                {
                    if (move != MoveType.Mine 
                        && move != MoveType.Fire
                        && move != MoveType.Move)
                    {
                        int speed = current.speed;
                        int rotation = current.rotation;

                        switch (move)
                        {
                            case MoveType.Faster:
                                speed += 1;
                                break;
                            case MoveType.Slower:
                                speed -= 1;
                                break;
                            case MoveType.Right:
                                rotation = (current.rotation + 5) % 6;
                                break;
                            case MoveType.Left:
                                rotation = (current.rotation + 1) % 6;
                                break;
                            default:
                                break;
                        }

                        if (speed > 2 || speed < 0)
                        {
                            continue;
                        }

                        Vector pos = current.pos + Vector.directions[current.rotation] * speed;
                        PositionNode newNode = new PositionNode(pos, move, rotation, current.rotation, speed, step);                        
                                                
                        if (!dist.ContainsKey(newNode) && isPositionSafe(newNode))
                        {
                            dist.Add(newNode, 999);
                            prev.Add(newNode, null);

                            current.neighbours.Add(newNode);
                            nextExpand.Add(newNode);
                        }
                    }

                    if (q.Count == 0 && nextExpand.Count > 0) //if bfs is done expanding current step and next expand has items
                    {
                        nextExpand.ForEach(n => q.Enqueue(n)); //put all list items into queue
                        nextExpand.Clear();

                        step++; //add 1 more step to count the distance
                    }
                }                
            }
        }

        public static PathInfo CalculateShortestPaths(Ship ship)
        {
            float loopStartTime = Timer.TickCount;

            Dictionary<PositionNode, int> dist = new Dictionary<PositionNode, int>();
            Dictionary<PositionNode, PositionNode> prev = new Dictionary<PositionNode, PositionNode>();

            Dictionary<Vector, List<PositionNode>> pathTable = new Dictionary<Vector, List<PositionNode>>();

            PathInfo pathInfo = new PathInfo(ship, dist, prev);

            InitializeShortestPaths(pathInfo);
                        
            var nodes = dist.Keys.ToList();

            float loopTime = Timer.TickCount - loopStartTime;
            Console.Error.WriteLine("LoopTime: " + loopTime);            

            for (int i = 0; i < nodes.Count;i++ )
            {
                var node = nodes[i];

                List<PositionNode> pathList;
                if (pathTable.TryGetValue(node.pos, out pathList))
                {
                    pathList.Add(node);
                }
                else
                {
                    pathList = new List<PositionNode>();
                    pathTable.Add(node.pos, pathList);
                }

                foreach (var neighbour in node.neighbours)
                {
                    int weight = neighbour.rotation == node.rotation && neighbour.speed == node.speed ? 1 : 2;
                    int alternativeDistance = node.distance + weight;

                    if (alternativeDistance < neighbour.distance)
                    {
                        dist[neighbour] = alternativeDistance;
                        prev[neighbour] = node;

                        neighbour.distance = alternativeDistance;
                        neighbour.parent = node;
                    }
                }
            }

            

            pathInfo.pathTable = pathTable;

            return pathInfo;
        }

        public static bool isPositionSafe(PositionNode node)
        {
            List<Vector> checkList = new List<Vector>
            {
                node.pos + Vector.directions[node.rotation],
                node.pos,
                node.pos + Vector.directions[(node.rotation + 3) % 6],                
            };

            if (node.prevRotation != node.rotation)
            {
                checkList.Add(node.pos + Vector.directions[node.prevRotation]);
                checkList.Add(node.pos + Vector.directions[(node.prevRotation + 3) % 6]);
            }

            if (!node.pos.isInBound())
            {
                return false;
            }

            /*foreach (var check in checkList)
            {
                if (!check.ConvertHex().isInBound2())
                {
                    return false;
                }
            }*/

            foreach (var cannon in Cannon.cannons)
            {
                foreach (var check in checkList)
                {
                    if (cannon.turns == node.step && cannon.pos == check)
                    {
                        return false;
                    }
                }
            }

            foreach (var mine in Mine.mines)
            {
                foreach (var check in checkList)
                {
                    if (mine.pos == check)
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    static class ShipMovement
    {
        public static Action Dodge(this Ship ship, Cannon cannon)
        {
            Action action = null;

            if (cannon.turns == 1)
            {
                if (ship.speed == 0 && ship.pos == cannon.pos)
                {
                    action = new Action(MoveType.Faster, ship);
                }
                else if (ship.speed > 0 && ship.nextPositionInfo.pos == cannon.pos)
                {
                    action = new Action(MoveType.Slower, ship);
                }
                else if (ship.nextPositionInfo.shipBack == cannon.pos)
                {
                    
                }
            }

            return action;
        }

        public static Action MoveShip(this Ship ship, Vector targetPosition)
        {
            Action action = null;

            var path = ship.paths.GetNextStep(targetPosition);
            if (path != null && path.Count > 1)
            {
                ship.targetPosition = targetPosition;
                var next = path[0];

                /*foreach(var node in path)
                {
                    Console.Error.WriteLine(node.moveType + "-> " + node.pos.toStr());
                }*/

                action = new Action(next.moveType, ship);
            }

            return action;
        }

        /*public static Action MoveShip2(this Ship ship, Vector targetPosition)
        {
            Action action = null;

            var path = ship.paths.GetNextStep(targetPosition);            
            if (path.Count >= 2)
            {
                ship.targetPosition = targetPosition;

                var nextPos = path[0];
                var nextPos2 = path[1];

                if (path.Count > 2)
                {
                    Console.Error.WriteLine(
                       nextPos.ConvertHex().toStr() + " -> "
                        + path[1].ConvertHex().toStr() + " -> "
                        + path[2].ConvertHex().toStr());
                }
                else
                {
                    Console.Error.WriteLine(nextPos.ConvertHex().toStr() + " -> "
                        + path[1].ConvertHex().toStr());
                }

                if (ship.speed > 1 && path.Count > 3
                    && path[3].GetRotation(path[2]) != ship.rotation
                    && path[3].GetRotation(path[2]) != path[2].GetRotation(path[1]))
                {
                    action = new Action(MoveType.Slower, ship);
                }
                else if (nextPos == ship.nextPositionInfo.shipRight
                    || nextPos2 == ship.nextPositionInfo.shipRight
                    || (path.Count > 2 && path[2] == ship.nextPositionInfo.shipRight))
                {
                    action = new Action(MoveType.Right, ship);
                }
                else if (nextPos == ship.nextPositionInfo.shipLeft
                    || nextPos2 == ship.nextPositionInfo.shipLeft
                    || (path.Count > 2 && path[2] == ship.nextPositionInfo.shipLeft))
                {
                    action = new Action(MoveType.Left, ship);
                }
                else if (ship.speed > 1 && path.Count > 3 && path[3].GetRotation(path[2]) != ship.rotation)
                {
                    action = new Action(MoveType.Slower, ship);
                }
                else if (ship.speed == 1 && nextPos.GetRotation(ship.currentPositionInfo.pos) != ship.rotation)
                {
                    action = new Action(MoveType.Slower, ship);
                }
                else if (ship.speed == 0 && nextPos.GetRotation(ship.pos) == ship.rotation)
                {
                    action = new Action(MoveType.Faster, ship);
                }
                /*else if (ship.speed < 2 && path.Count > 3 
                    && path[3].GetRotation(path[2]) == ship.rotation
                    && path[3].GetRotation(path[2]) == path[2].GetRotation(path[1])
                    && Pathfinding.isPositionSafe(ship, ship.rotation, path[2], path[1], 1))
                {
                    action = new Action(MoveType.Faster, ship);
                }
                else if (ship.speed > 0 && path.Count > 2 && path[2].GetRotation(path[1]) == ship.rotation
                        || path[1].GetRotation(path[0]) == ship.rotation)
                {
                    action = new Action(ship);
                }
                else //i am a noob
                {
                    //action = new Action(MoveType.Move, ship, targetPosition);
                }

            }
            else //i am a noob
            {
                //action = new Action(MoveType.Move, ship, targetPosition);
            }

            if (Strategy.random.Next(0, 2) == 0)
            {
                return new Action(MoveType.Move, ship, targetPosition);
            }
            else
            {
                return new Action(ship);
            }
            return action;
        }*/

        public static Action RandomPosition(this Ship ship, Vector targetPosition, int min, int max)
        {
            int count=0;
            while (count < 50)
            {
                var randPos = targetPosition.GetRandomPosition(min, max);

                Action action = ship.MoveShip(randPos);
                if (action != null)
                {
                    return action;
                }
                count++;
            }

            return null;
        }
    }
}

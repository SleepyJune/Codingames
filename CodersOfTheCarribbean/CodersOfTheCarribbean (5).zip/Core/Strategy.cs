﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class Strategy
    {
        public static Random random = new Random();

        public static void ShipMakeMove(Ship ship)
        {

            bool waitMove = false;

            foreach (var cannon in Cannon.cannons)
            {
                //var shipPredictedPos = ship.GetPredictedPos(cannon.turns);

                if (cannon.turns <= 3 && ship.WillCannonHitShip(cannon))
                {
                    if (false)//(ship.speed == 0 && ship.lastMoveCommand.Distance(ship.pos) > 4)
                    {
                        var action = new Action(MoveType.Faster, ship);
                        Action.AddAction(action);
                        return;
                    }
                    else
                    {
                        int randX = random.Next(0, 22);
                        int randY = random.Next(0, 20);

                        Hex hex = new Hex(randX, randY);

                        Vector randomPos = hex.ConvertCube();
                        Console.Error.WriteLine("Dodging");

                        Action action = ship.Dodge(cannon);

                        if (action != null)
                        {
                            Action.AddAction(action);
                            return;
                        }
                        else
                        {
                            action = ship.MoveShip(randomPos);
                            if (action != null && action.move != MoveType.Move)
                            {
                                Action.AddAction(action);
                                return;
                            }
                        }
                    }
                }
            }

            

            foreach (var barrel in Barrel.barrels.OrderBy(b => ship.nextPositionInfo.pos.Distance(b.pos) 
                            - Convert.ToInt32(ship.targetPosition == b.pos)*100))
            {
                bool sameTarget = false;
                foreach (var ally in Ship.ships.Values)
                {
                    if (ally.team == Team.Ally && ally.isAlive && ally != ship 
                        && ally.targetPosition == barrel.pos)
                    {
                        sameTarget = true;
                        break;
                    }
                }

                if (sameTarget)
                {
                    continue;
                }


                Console.Error.WriteLine("Target: " + barrel.pos.ConvertHex().toStr());
                Console.Error.WriteLine("ShipNext: " + ship.nextPositionInfo.pos.toStr());

                Action action = ship.MoveShip(barrel.pos);

                if (action != null)
                {
                    if (action.move != MoveType.Wait)
                    {
                        Action.AddAction(action);
                        return;
                    }
                    else
                    {
                        waitMove = true;
                        break;
                    }                    
                }

            }

            if (ship.speed >= 1 && ship.lastMoveCommand != Vector.Undefined)
            {

            }
            else
            {
                foreach (var enemy in Ship.ships.Values.OrderByDescending(s => s.rum))
                {
                    if (enemy.team == Team.Enemy && enemy.isAlive)
                    {
                        Console.Error.WriteLine("Random enemy: " + enemy.id);

                        Action action = ship.RandomPosition(enemy.nextPositionInfo.shipFront, 5, 10);
                        if (action != null)
                        {
                            if (action.move != MoveType.Wait)
                            {
                                Action.AddAction(action);
                                return;
                            }
                            else
                            {
                                waitMove = true;
                                break;
                            }
                        }
                    }
                }
            }

            if (ship.firedLastRound == false)
            {
                foreach (var enemy in Ship.ships.Values.OrderByDescending(s => s.rum))
                {
                    if (enemy.team == Team.Enemy && enemy.isAlive)
                    {
                        //Console.Error.WriteLine("ATK " + enemy.id + ":" + enemy.pos.toStr());

                        var predictedPos = ship.GetPredictedFirePos(enemy);

                        if (predictedPos.Distance(ship.currentPositionInfo.shipFront) <= 11)
                        {
                            var action = new Action(MoveType.Fire, ship, predictedPos);
                            Action.AddAction(action);
                            return;
                        }
                    }
                }
            }
            /*else
            {
                var action = new Action(MoveType.Mine, ship);
                Action.AddAction(action);
                return;
            }*/          

            Action.AddAction(new Action(ship));
        }

        public static void MakeMove()
        {

            foreach (var ship in Ship.ships.Values)
            {
                if (ship.team == Team.Ally && ship.isAlive)
                {                
                    ShipMakeMove(ship);
                    //Action.AddAction(new Action(ship));
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class PathInfo
    {
        public Dictionary<Vector, int> dist = new Dictionary<Vector, int>();
        public Dictionary<Vector, PositionNode> prev = new Dictionary<Vector, PositionNode>();

        public Dictionary<Vector, List<PositionNode>> pathTable = new Dictionary<Vector, List<PositionNode>>();

        public Ship ship;

        public PathInfo(Ship ship, Dictionary<Vector, int> dist, Dictionary<Vector, PositionNode> prev)
        {
            this.ship = ship;

            this.dist = dist;
            this.prev = prev;
        }

        public PositionNode GetNextStep(Vector target)
        {
            List<PositionNode> pathList;

            if (pathTable.TryGetValue(target, out pathList))
            {
                foreach (var node in pathList.OrderBy(n=>n.step))
                {
                    PositionNode current = node;

                    while (current.parent != null && current.parent.pos != ship.pos)
                    {
                        current = current.parent;    
                    }

                    if (current != null)
                    {
                        return current;
                    }
                }
            }

            return null;
        }
    }
}

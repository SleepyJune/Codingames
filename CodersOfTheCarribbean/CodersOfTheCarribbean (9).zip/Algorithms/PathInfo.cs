﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class PathInfo
    {
        public Dictionary<Vector, List<PositionNode>> pathTable = new Dictionary<Vector, List<PositionNode>>();

        public Ship ship;

        public PathInfo(Ship ship)
        {
            this.ship = ship;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class Mine : Entity, IEquatable<Mine>
    {
        public static HashSet<Mine> mines = new HashSet<Mine>();
        public static HashSet<Vector> minePos = new HashSet<Vector>();

        public Mine()
        {

        }

        public override void ProcessMessage(EntityMessage message)
        {
            this.pos = message.pos.ConvertCube();

            if (!minePos.Contains(this.pos))
            {
                minePos.Add(this.pos);
            }
        }

        public static void CleanUp()
        {
            mines = new HashSet<Mine>();
            minePos = new HashSet<Vector>();
        }

        public static Mine GetMineByID(int id)
        {
            Mine mine = new Mine();
            mines.Add(mine);
            return mine;
        }

        public override bool Equals(object obj)
        {
            if (obj is Mine)
            {
                return Equals((Mine)this);
            }

            return false;
        }

        public bool Equals(Mine obj)
        {
            return obj.pos == this.pos;
        }

        public override int GetHashCode()
        {
            return this.pos.GetHashCode();
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Priority_Queue
{
    public class SimplePriorityQueue<TItem, TPriority> : IPriorityQueue<TItem, TPriority>
        where TPriority : IComparable<TPriority>
    {
        private class SimpleNode : GenericPriorityQueueNode<TPriority>
        {
            public TItem Data { get; private set; }

            public SimpleNode(TItem data)
            {
                Data = data;
            }
        }

        private const int INITIAL_QUEUE_SIZE = 10;
        private readonly GenericPriorityQueue<SimpleNode, TPriority> _queue;

        public SimplePriorityQueue()
        {
            _queue = new GenericPriorityQueue<SimpleNode, TPriority>(INITIAL_QUEUE_SIZE);
        }
        private SimpleNode GetExistingNode(TItem item)
        {
            var comparer = EqualityComparer<TItem>.Default;
            foreach(var node in _queue)
            {
                if(comparer.Equals(node.Data, item))
                {
                    return node;
                }
            }
            throw new InvalidOperationException("Item cannot be found in queue: " + item);
        }
        public int Count
        {
            get
            {
                lock(_queue)
                {
                    return _queue.Count;
                }
            }
        }
        public TItem First
        {
            get
            {
                lock(_queue)
                {
                    if(_queue.Count <= 0)
                    {
                        throw new InvalidOperationException("Cannot call .First on an empty queue");
                    }

                    SimpleNode first = _queue.First;
                    return (first != null ? first.Data : default(TItem));
                }
            }
        }
        public void Clear()
        {
            lock(_queue)
            {
                _queue.Clear();
            }
        }
        public bool Contains(TItem item)
        {
            lock(_queue)
            {
                var comparer = EqualityComparer<TItem>.Default;
                foreach (var node in _queue)
                {
                    if (comparer.Equals(node.Data, item))
                    {
                        return true;
                    }
                }
                return false;
            }
        }
        public TItem Dequeue()
        {
            lock(_queue)
            {
                if(_queue.Count <= 0)
                {
                    throw new InvalidOperationException("Cannot call Dequeue() on an empty queue");
                }

                SimpleNode node =_queue.Dequeue();
                return node.Data;
            }
        }
        public void Enqueue(TItem item, TPriority priority)
        {
            lock(_queue)
            {
                SimpleNode node = new SimpleNode(item);
                if(_queue.Count == _queue.MaxSize)
                {
                    _queue.Resize(_queue.MaxSize*2 + 1);
                }
                _queue.Enqueue(node, priority);
            }
        }
        public void Remove(TItem item)
        {
            lock(_queue)
            {
                try
                {
                    _queue.Remove(GetExistingNode(item));
                }
                catch(InvalidOperationException ex)
                {
                    throw new InvalidOperationException("Cannot call Remove() on a node which is not enqueued: " + item, ex);
                }
            }
        }
        public void UpdatePriority(TItem item, TPriority priority)
        {
            lock (_queue)
            {
                try
                {
                    SimpleNode updateMe = GetExistingNode(item);
                    _queue.UpdatePriority(updateMe, priority);
                }
                catch(InvalidOperationException ex)
                {
                    throw new InvalidOperationException("Cannot call UpdatePriority() on a node which is not enqueued: " + item, ex);
                }
            }
        }

        public IEnumerator<TItem> GetEnumerator()
        {
            List<TItem> queueData = new List<TItem>();
            lock (_queue)
            {
                //Copy to a separate list because we don't want to 'yield return' inside a lock
                foreach(var node in _queue)
                {
                    queueData.Add(node.Data);
                }
            }

            return queueData.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public bool IsValidQueue()
        {
            lock(_queue)
            {
                return _queue.IsValidQueue();
            }
        }
    }
    public class SimplePriorityQueue<TItem> : SimplePriorityQueue<TItem, float> { }
}
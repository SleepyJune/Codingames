﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class Pathfinding
    {
        public static Dictionary<PositionNode, PositionNode> nodeTable = new Dictionary<PositionNode, PositionNode>();

        public static void InitializeShortestPaths()
        {
            InitializeNodes();
            InitializeNeighbours();
        }

        public static void InitializeNodes()
        {
            for (int x = 0; x <= 22; x++)
            {
                for (int y = 0; y <= 20; y++)
                {
                    for (int speed = 0; speed <= 2; speed++)
                    {
                        for (int rotation = 0; rotation < Vector.directions.Count; rotation++)
                        {
                            Hex hexPos = new Hex(x, y);
                            Vector pos = hexPos.ConvertCube();

                            PositionNode newNode = new PositionNode(pos, rotation, speed);
                            nodeTable.Add(newNode, newNode);
                        }
                    }
                }
            }
        }

        public static void InitializeNeighbours()
        {
            List<MoveType> validMoves = new List<MoveType>
            {
                MoveType.Wait,
                MoveType.Left,
                MoveType.Right,
                MoveType.Faster,
                MoveType.Slower,
            };

            foreach (var current in nodeTable.Values)
            {
                foreach (MoveType move in validMoves)
                {
                    int speed = current.speed;
                    int rotation = current.rotation;

                    switch (move)
                    {
                        case MoveType.Faster:
                            speed += 1;
                            break;
                        case MoveType.Slower:
                            speed -= 1;
                            break;
                        case MoveType.Right:
                            rotation = (current.rotation + 5) % 6;
                            break;
                        case MoveType.Left:
                            rotation = (current.rotation + 1) % 6;
                            break;
                        default:
                            break;
                    }

                    if (speed > 2 || speed < 0 ||
                       (speed == 0 && move == MoveType.Wait))
                    {
                        continue;
                    }

                    Vector pos = current.pos + Vector.directions[current.rotation] * speed;
                    PositionNode newNode = new PositionNode(pos, rotation, speed);

                    if (pos.isInBound())
                    {
                        current.neighbours.Add(nodeTable[newNode], move);
                    }

                }
            }
        }

        public static PositionNode GetLongestPath(Ship ship, int radius, bool fleeing = false)
        {
            HashSet<PositionNode> set = new HashSet<PositionNode>();
            Queue<PositionNode> q = new Queue<PositionNode>();
            List<PositionNode> nextExpand = new List<PositionNode>();

            PositionNode shipNode = PositionNode.GetPositionNode(ship.pos, ship.rotation, ship.speed);
            shipNode.distance = 0;
            shipNode.step = 0;
            shipNode.parent = null;

            set.Add(shipNode);
            q.Enqueue(shipNode);

            int step = 0;
            int loops = 0;

            PositionNode current = null;

            // bfs loop
            while (q.Count != 0)
            {
                current = q.Dequeue();

                foreach (var pair in current.neighbours)
                {
                    var neighbour = pair.Key;
                    var move = pair.Value;

                    int neighbourStep = step + 1;//current.step + 1;

                    neighbour.prevRotation = current.rotation;

                    if (!set.Contains(neighbour) && isPositionSafe(neighbour, ship, neighbourStep))
                    {
                        set.Add(neighbour);

                        neighbour.parent = current;
                        neighbour.moveType = move;
                        neighbour.step = neighbourStep;

                        nextExpand.Add(neighbour);
                    }
                }

                if (q.Count == 0 && nextExpand.Count > 0) //if bfs is done expanding current step and next expand has items
                {
                    if (step >= radius)
                    {
                        break;
                    }

                    nextExpand.ForEach(n => q.Enqueue(n)); //put all list items into queue
                    nextExpand.Clear();

                    step++; //add 1 more step to count the distance
                }

                loops++;
            }

            if (step >= radius && nextExpand.Count > 0)
            {
                PositionNode first = null;
                if (fleeing)
                {
                    first = nextExpand.OrderByDescending(n => CombinedDistanceFromEnemy(n.pos)).FirstOrDefault();
                }
                else
                {
                    first = nextExpand.OrderByDescending(n => n.pos.Distance(ship.pos)).FirstOrDefault();
                }

                return first;

            }

            return null;
        }

        public static double CombinedDistanceFromEnemy(Vector vec)
        {
            double combinedDistance = 0;

            foreach (var enemy in Ship.ships.Values)
            {
                if (enemy.isAlive && enemy.team == Team.Enemy)
                {
                    combinedDistance += enemy.nextPositionInfo.shipFront.Distance(vec);
                }
            }

            return combinedDistance;
        }
                
        public static PositionNode CalculateShortestPaths(Ship ship, Vector targetPosition)
        {
            float loopStartTime = Timer.TickCount;
            float loopTime = 0;

            float timeAvailable = 40 / Ship.numAllyShips;

            if (Game.timeLeft <= 0)
            {
                Console.Error.WriteLine("Not enough time left.");
                return null;
            }

            if (!targetPosition.isPositionReachable())
            {
                Console.Error.WriteLine("Impossible position: " + targetPosition.toStr());
                return null;
            }

            HashSet<PositionNode> set = new HashSet<PositionNode>();
            Queue<PositionNode> q = new Queue<PositionNode>();
            List<PositionNode> nextExpand = new List<PositionNode>();

            PositionNode shipNode = PositionNode.GetPositionNode(ship.pos, ship.rotation, ship.speed);
            shipNode.distance = 0;
            shipNode.step = 0;
            shipNode.parent = null;

            set.Add(shipNode);
            q.Enqueue(shipNode);

            int step = 0;
            int loops = 0;

            PositionNode current = null;

            // bfs loop
            while (q.Count != 0)
            {
                current = q.Dequeue();

                if (loops % 100 == 0)
                {
                    loopTime = Timer.TickCount - loopStartTime;
                    if (loopTime > timeAvailable)
                    {
                        Console.Error.WriteLine("Loops: " + loops + " Steps: " + step);
                        Console.Error.WriteLine("TimeOut: " + loopTime);
                        Game.timeLeft -= (int)loopTime;
                        return null;
                    }
                }

                if (current.pos == targetPosition)
                {
                    break;
                }

                foreach (var pair in current.neighbours)
                {
                    var neighbour = pair.Key;
                    var move = pair.Value;

                    int neighbourStep = step+1;//current.step + 1;

                    neighbour.prevRotation = current.rotation;

                    if (!set.Contains(neighbour) && isPositionSafe(neighbour, ship, neighbourStep))
                    {
                        set.Add(neighbour);

                        neighbour.parent = current;
                        neighbour.moveType = move;
                        neighbour.step = neighbourStep;

                        nextExpand.Add(neighbour);
                    }
                }

                if (q.Count == 0 && nextExpand.Count > 0) //if bfs is done expanding current step and next expand has items
                {
                    nextExpand.ForEach(n => q.Enqueue(n)); //put all list items into queue
                    nextExpand.Clear();

                    step++; //add 1 more step to count the distance
                }

                loops++;
            }

            loopTime = Timer.TickCount - loopStartTime;
            Console.Error.WriteLine("LoopTime: " + loopTime);
            Console.Error.WriteLine("Loops: " + loops + " Steps: " + step);

            Game.timeLeft -= (int)loopTime;

            return current;
        }

        public static bool isPositionSafe(PositionNode node, Ship ship, int step)
        {            
            foreach (var cannon in ship.dodgeableCannons)
            {
                foreach (var check in node.checkList)
                {                    
                    if (cannon.turns == step && cannon.hexPos == check)
                    {
                        return false;
                    }
                }
            }
                                                
            foreach (var check in node.checkList)
            {
                if (Mine.minePos.Contains(check))
                {
                    return false;
                }

                if (ship.enemyShipCollisionCheck.Contains(check))
                {
                    return false;
                }
            }

            if (node.rotation != node.prevRotation)
            {
                if (Mine.minePos.Contains(node.extraCheckList[node.prevRotation]))
                {
                    return false;
                }

                if (ship.enemyShipCollisionCheck.Contains(node.extraCheckList[node.prevRotation]))
                {
                    return false;
                }
            }

            return true;
        }
    }
}

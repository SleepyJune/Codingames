﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class PathInfo
    {
        public Dictionary<Vector, List<PositionNode>> pathTable = new Dictionary<Vector, List<PositionNode>>();

        public Ship ship;

        public PathInfo(Ship ship)
        {
            this.ship = ship;
        }

        public List<PositionNode> GetNextStep(Vector target)
        {
            List<PositionNode> pathList;

            if (pathTable.TryGetValue(target, out pathList))
            {
                foreach (var node in pathList.OrderBy(n=>n.distance))
                {
                    PositionNode current = node;
                    List<PositionNode> path = new List<PositionNode>();

                    while (current.parent != null && current.pos != ship.pos)
                    {
                        path.Add(current);
                        current = current.parent;    
                    }

                    if (current != null && current.pos == ship.pos)
                    {
                        path.Reverse();
                        return path;
                    }
                }
            }

            return null;
        }

        /*public List<Vector> GetNextStep(Vector target)
        {
            List<Vector> ret = new List<Vector>();
            Vector current = target;

            /*while (prev.ContainsKey(current))
            {
                //Console.Error.WriteLine("Track: " + current.toStr());

                ret.Add(current);

                if (prev[current] == ship.pos)
                {
                    break;
                }
                current = prev[current];
            }

            ret.Reverse();
            return ret;
        }*/
    }
}

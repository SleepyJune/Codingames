﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class Pathfinding
    {
        public static Dictionary<PositionNode, PositionNode> nodeTable = new Dictionary<PositionNode, PositionNode>();
        public static Dictionary<MovementEdge, MovementEdge> edgeTable = new Dictionary<MovementEdge, MovementEdge>();

        public static void InitializeShortestPaths()
        {            
            InitializeNodes();
            InitializeNeighbours();            
        }

        public static void InitializeNodes()
        {
            for (int x = 0; x <= 22; x++)
            {
                for (int y = 0; y <= 20; y++)
                {
                    for (int speed = 0; speed <= 2; speed++)
                    {
                        for (int rotation = 0; rotation < Vector.directions.Count; rotation++)
                        {
                            Hex hexPos = new Hex(x, y);
                            Vector pos = hexPos.ConvertCube();

                            PositionNode newNode = new PositionNode(pos, rotation, speed);
                            nodeTable.Add(newNode, newNode);
                        }
                    }
                }
            }
        }

        public static void InitializeNeighbours()
        {
            List<MoveType> validMoves = new List<MoveType>
            {
                MoveType.Wait,
                MoveType.Left,
                MoveType.Right,
                MoveType.Faster,
                MoveType.Slower,
            };

            foreach(var current in nodeTable.Values)
            {
                foreach (MoveType move in validMoves)
                {
                    int speed = current.speed;
                    int rotation = current.rotation;

                    switch (move)
                    {
                        case MoveType.Faster:
                            speed += 1;
                            break;
                        case MoveType.Slower:
                            speed -= 1;
                            break;
                        case MoveType.Right:
                            rotation = (current.rotation + 5) % 6;
                            break;
                        case MoveType.Left:
                            rotation = (current.rotation + 1) % 6;
                            break;
                        default:
                            break;
                    }

                    if (speed > 2 || speed < 0)
                    {
                        continue;
                    }

                    Vector pos = current.pos + Vector.directions[current.rotation] * speed;
                    PositionNode newNode = new PositionNode(pos, rotation, speed);

                    if (pos.isInBound())
                    {
                        current.neighbours.Add(nodeTable[newNode], move);

                        //MovementEdge edge = new MovementEdge(current, newNode, move);
                        //edgeTable.Add(edge, edge);
                    }

                }                         
            }
        }

        public static PathInfo CalculateShortestPaths(Ship ship, Vector targetPosition)
        {
            float loopStartTime = Timer.TickCount;

            HashSet<PositionNode> set = new HashSet<PositionNode>();
            Queue<PositionNode> q = new Queue<PositionNode>();
            List<PositionNode> nextExpand = new List<PositionNode>();      
      
            PositionNode shipNode = new PositionNode(ship.pos, ship.rotation, ship.speed);
            shipNode = nodeTable[shipNode];
            shipNode.distance = 0;
            shipNode.step = 0;
            
            q.Enqueue(shipNode);

            int step = 0;
            PositionNode current = null;

            // bfs loop
            while (q.Count != 0)
            {
                current = q.Dequeue();

                if (current.pos == targetPosition)
                {                    
                    break;
                }

                foreach (var pair in current.neighbours)
                {
                    var neighbour = pair.Key;
                    var move = pair.Value;

                    if (!set.Contains(neighbour) && isPositionSafe(neighbour))
                    {
                        set.Add(neighbour);

                        neighbour.parent = current;
                        q.Enqueue(neighbour);
                    }
                }

                if (q.Count == 0 && nextExpand.Count > 0) //if bfs is done expanding current step and next expand has items
                {
                    nextExpand.ForEach(n => q.Enqueue(n)); //put all list items into queue
                    nextExpand.Clear();

                    step++; //add 1 more step to count the distance
                }
            }

            float loopTime = Timer.TickCount - loopStartTime;
            Console.Error.WriteLine("LoopTime: " + loopTime);

            return null;
        }
     
        public static PathInfo CalculateShortestPaths2(Ship ship)
        {
            float loopStartTime = Timer.TickCount;

            Dictionary<Vector, List<PositionNode>> pathTable = new Dictionary<Vector, List<PositionNode>>();

            PathInfo pathInfo = new PathInfo(ship);

            foreach (var node in nodeTable.Values)
            {
                node.distance = 999;
                node.parent = null;
            } 

            HashSet<PositionNode> visited = new HashSet<PositionNode>();

            PositionNode shipNode = new PositionNode(ship.pos, ship.rotation, ship.speed);
            shipNode = nodeTable[shipNode];
            shipNode.distance = 0;
            shipNode.step = 0;

            visited.Add(shipNode);

            Console.Error.WriteLine(edgeTable.Count);
                               
            foreach(var node in nodeTable.Values)
            {
                List<PositionNode> pathList;
                if (pathTable.TryGetValue(node.pos, out pathList))
                {
                    pathList.Add(node);
                }
                else
                {
                    pathList = new List<PositionNode>();
                    pathTable.Add(node.pos, pathList);
                }

                foreach (var pair in node.neighbours)
                {
                    var neighbour = pair.Key;
                    var move = pair.Value;

                    int weight = move == MoveType.Wait ? 1 : 2;
                    int distance = visited.Contains(node) ? node.distance : 999;
                    int alternativeDistance = distance + weight;

                    if (alternativeDistance < neighbour.distance && isPositionSafe(neighbour))
                    {
                        if (!visited.Contains(neighbour))
                        {
                            visited.Add(neighbour);
                        }

                        neighbour.distance = alternativeDistance;
                        neighbour.parent = node;
                        neighbour.moveType = move;
                        neighbour.step = node.step + 1;
                    }
                }
            }

            float loopTime = Timer.TickCount - loopStartTime;
            Console.Error.WriteLine("LoopTime: " + loopTime);

            pathInfo.pathTable = pathTable;

            return pathInfo;
        }

        public static bool isPositionSafe(PositionNode node)
        {
            List<Vector> checkList = new List<Vector>
            {
                node.pos + Vector.directions[node.rotation],
                node.pos,
                node.pos + Vector.directions[(node.rotation + 3) % 6],                
            };

            if (node.prevRotation != node.rotation)
            {
                checkList.Add(node.pos + Vector.directions[node.prevRotation]);
                checkList.Add(node.pos + Vector.directions[(node.prevRotation + 3) % 6]);
            }

            /*foreach (var check in checkList)
            {
                if (!check.ConvertHex().isInBound2())
                {
                    return false;
                }
            }*/

            /*foreach (var cannon in Cannon.cannons)
            {
                foreach (var check in checkList)
                {
                    if (cannon.turns == node.step && cannon.pos == check)
                    {
                        return false;
                    }
                }
            }*/

            foreach (var check in checkList)
            {
                if (Mine.minePos.Contains(check))
                {
                    return false;
                }
            }

            return true;
        }
    }
}

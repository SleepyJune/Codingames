﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class MovementEdge
    {
        public PositionNode from;
        public PositionNode to;

        public MoveType move;

        public MovementEdge(PositionNode from, PositionNode to, MoveType move)
        {
            this.from = from;
            this.to = to;
            this.move = move;
        }
    }
}

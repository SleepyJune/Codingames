﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class Pathfinding
    {
        public static PathInfo CalculateShortestPaths(Ship ship)
        {
            //float loopStartTime = Timer.TickCount;

            Dictionary<Vector, Vector> prev = new Dictionary<Vector, Vector>();
            /*for (int x = 0; x < 23; x++)
            {
                for (int y = 0; y < 21; y++)
                {
                    Vector pos = (new Hex(x, y)).ConvertCube();
                    prev.Add(pos, Vector.Undefined);
                }
            }*/

            //BFS start

            HashSet<Vector> set = new HashSet<Vector>();
            Queue<Vector> q = new Queue<Vector>();
            List<Vector> nextExpand = new List<Vector>();      
      
            var shipPos = ship.GetPredictedPos(1, 1);
            var shipPosInfo = new ShipPositionInfo(shipPos, ship.rotation);
            prev[shipPosInfo.pos] = shipPosInfo.shipBack;
            q.Enqueue(shipPosInfo.pos);


            //prev[ship.pos] = ship.currentPositionInfo.shipBack;
            //q.Enqueue(ship.pos);

            int step = ship.speed == 0 ? 2 : 1;
            Vector current = Vector.Undefined;


            // bfs loop
            while (q.Count != 0)
            {
                current = q.Dequeue();

                //var lastDir = (current - prev[current]).Normalized();
                //Console.Error.WriteLine(current.toStr());
                //var lastRotation = Vector.directionTable[lastDir];
                var lastRotation = current.GetRotation(prev[current]);

                List<int> possibleRotations = new List<int>
                {
                    lastRotation, //forward
                    (lastRotation + 5)%6, //right
                    (lastRotation + 1)%6, //left
                };

                if (ship.speed >= 2 && current == shipPosInfo.pos)
                {
                    possibleRotations = new List<int> { lastRotation };
                }

                foreach (int rotation in possibleRotations)
                {
                    //var hex = pos.ConvertHex();

                    var pos = current + Vector.directions[rotation];

                    if (!set.Contains(pos) && isPositionSafe(ship, rotation, pos, current, step))
                    {
                        set.Add(pos);

                        if (!prev.ContainsKey(pos))
                        {
                            prev.Add(pos, current);

                        }
                        q.Enqueue(pos);
                    }
                }

                if (q.Count == 0 && nextExpand.Count > 0) //if bfs is done expanding current step and next expand has items
                {
                    nextExpand.ForEach(n => q.Enqueue(n)); //put all list items into queue
                    nextExpand.Clear();
                                        
                    step++; //add 1 more step to count the distance
                }
            }

            //float loopTime = Timer.TickCount - loopStartTime;
            //Console.Error.WriteLine("LoopTime: " + loopTime);

            return new PathInfo(ship, null, prev);
        }

        public static bool isPositionSafe(Ship ship, int rotation, Vector pos, Vector current, int step)
        {            
            ShipPositionInfo posInfo = new ShipPositionInfo(pos, rotation);
            ShipPositionInfo posInfo2 = new ShipPositionInfo(current, rotation);

            List<Vector> checkList = new List<Vector>
            {
                posInfo.shipFront, posInfo.pos, posInfo2.pos, posInfo2.shipBack
            };

            foreach (var check in checkList)
            {
                if (!check.ConvertHex().isInBound2())
                {
                    return false;
                }
            }
            

            foreach (var mine in Mine.mines)
            {
                foreach (var check in checkList)
                {
                    if (mine.pos == check)
                    {
                        return false;
                    }
                }
            }

            foreach (var cannon in Cannon.cannons)
            {
                foreach (var check in checkList)
                {
                    if (cannon.turns <= step && cannon.pos == check)
                    {
                        return false;
                    }
                }
            }

            foreach (var s in Ship.ships.Values)
            {
                if (ship != s && s.nextPositionInfo.pos.Distance(pos) <= 6)
                {
                    /*foreach (var check in checkList)
                    {
                        if (s.nextPositionInfo.pos == check
                         || s.nextPositionInfo.shipFront == check
                         || s.nextPositionInfo.shipBack == check)
                        {
                            return false;
                        }
                    }*/

                    return false;
                }
            }

            return true;
        }
    }
}

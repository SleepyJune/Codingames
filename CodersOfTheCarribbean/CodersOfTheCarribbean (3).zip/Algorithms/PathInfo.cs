﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class PathInfo
    {        
        public Dictionary<Vector, int> dist = new Dictionary<Vector, int>();
        public Dictionary<Vector, Vector> prev = new Dictionary<Vector, Vector>();

        public Ship ship;

        public PathInfo(Ship ship, Dictionary<Vector, int> dist, Dictionary<Vector, Vector> prev)
        {
            this.ship = ship;

            this.dist = dist;
            this.prev = prev;
        }

        public List<Vector> GetNextStep(Vector target)
        {
            List<Vector> ret = new List<Vector>();
            Vector current = target;

            while (prev.ContainsKey(current))
            {
                //Console.Error.WriteLine("Track: " + current.toStr());

                ret.Add(current);

                if (prev[current] == ship.pos)
                {
                    break;
                }
                current = prev[current];
            }

            ret.Reverse();
            return ret;
        }
    }
}

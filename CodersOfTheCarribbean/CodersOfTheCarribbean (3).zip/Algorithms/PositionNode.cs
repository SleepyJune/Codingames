﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodersOfTheCarribbean
{
    class PositionNode
    {
        public Vector pos;
        public int rotation;
        public PositionNode parent;

        public PositionNode(Vector pos)
        {
            this.pos = pos;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Strategy
    {
        public static Random random = new Random();

        public static int[,] movementMatrix = new int[,]
        {
            {2,2,2,2},            
            {0,3,3,3},
            {3,0,3,4},
            {3,3,0,3},
            {3,4,3,0},
        };

        public static void MakeMove()
        {
            //Wait
            if (Player.me.eta > 0)
            {
                Action newAction = new Action(Player.me);
                Action.AddAction(newAction);
                return;
            }

            //Collect
            if (Player.me.module == Module.Start)
            {
                Action newAction = new Action(Player.me, Module.Samples);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Samples && Player.me.samples.Count < 3)
            {
                int exp = Player.me.CountExpertise();
                int rank = 1;

                if (exp > 3)
                {
                    rank = 2;
                }

                if (exp > 9)
                {
                    rank = 3;
                }
                

                Action newAction = new Action(Player.me, rank);
                Action.AddAction(newAction);
                return;                
            }

            Player.me.PrintPlayerStats();
            foreach (var sample in Player.me.samples)
            {
                sample.PrintStats();
            }

            //Analyze
            if (Player.me.module == Module.Samples)
            {
                Action newAction = new Action(Player.me, Module.Diagnosis);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Diagnosis)
            {
                //Console.Error.WriteLine(Player.me.samples.Count);

                foreach (var sample in Player.me.samples)//.OrderByDescending(s => s.health))
                {
                    if (sample.health == -1)
                    {
                        Action newAction = new Action(Player.me, sample);
                        Action.AddAction(newAction);
                        return;
                    }                    
                }
            }

            //Gather
            if (Player.me.module == Module.Diagnosis)
            {
                Action newAction = new Action(Player.me, Module.Molecules);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Molecules && Player.me.CountMolecules() < 10)
            {
                foreach (var sample in Player.me.samples.OrderBy(s => s.totalCost))
                {
                    if (!Player.me.hasEnoughMolecules(sample))
                    {
                        var missingMolecules = sample.molecules;

                        if (Molecule.canCompleteSample(missingMolecules) == false)
                        {
                            continue;
                        }

                        foreach (var pair in missingMolecules.OrderBy(p=>p.Key.count))
                        {                            
                            var molecule = pair.Key;
                            int count = pair.Value;

                            if (count > 0)
                            {
                                Action newAction = new Action(Player.me, molecule);
                                Action.AddAction(newAction);
                                return;
                            }
                        }
                    }
                    else
                    {
                        //break;
                    }
                    
                }
            }

            //Produce
            if (Player.me.module == Module.Molecules)
            {
                Action newAction = new Action(Player.me, Module.Laboratory);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Laboratory)
            {
                foreach (var sample in Player.me.samples.OrderByDescending(s => s.totalCost))
                {
                    if (Player.me.hasEnoughMolecules(sample))
                    {
                        Action newAction = new Action(Player.me, sample);
                        Action.AddAction(newAction);
                        return;
                    }

                }
            }

            //Go Back Collecting
            if (Player.me.module == Module.Laboratory)
            {
                if (Player.me.samples.Count > 0)
                {
                    Action newAction = new Action(Player.me, Module.Molecules);
                    Action.AddAction(newAction);
                    return;
                }
                else
                {
                    Action newAction = new Action(Player.me, Module.Samples);
                    Action.AddAction(newAction);
                    return;
                }
                
            }
        }
    }
}

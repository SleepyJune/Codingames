﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Molecule
    {
        public static Molecule a = new Molecule("A");
        public static Molecule b = new Molecule("B");
        public static Molecule c = new Molecule("C");
        public static Molecule d = new Molecule("D");
        public static Molecule e = new Molecule("E");

        //public static Dictionary<string, Molecule> molecules = new Dictionary<string, Molecule>();

        public string name;
        public int count;

        public Molecule(string name)
        {
            this.name = name;
            //molecules.Add(name, this);
        }

        public static void ProcessInputs(string[] inputs)
        {
            Molecule.a.count = int.Parse(inputs[0]);
            Molecule.b.count = int.Parse(inputs[1]);
            Molecule.c.count = int.Parse(inputs[2]);
            Molecule.d.count = int.Parse(inputs[3]);
            Molecule.e.count = int.Parse(inputs[4]);
        }

        public static bool canCompleteSample(Dictionary<Molecule, int> missingMolecules)
        {
            return !missingMolecules.Any(p => p.Key.count < p.Value);
        }
    }
}

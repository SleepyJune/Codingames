﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Sample
    {
        public static Dictionary<int, Sample> samples = new Dictionary<int, Sample>();

        public int id;
        public int carriedBy;
        public int rank;
        public string expertiseGain;
        public int health;
        public int costA;
        public int costB;
        public int costC;
        public int costD;
        public int costE;

        public Dictionary<Molecule, int> molecules = new Dictionary<Molecule, int>();

        public int totalCost;

        public Player player = null;

        public Sample()
        {

        }

        public void ProcessInputs(string[] inputs)
        {
            id = int.Parse(inputs[0]);
            carriedBy = int.Parse(inputs[1]);
            rank = int.Parse(inputs[2]);
            expertiseGain = inputs[3];
            health = int.Parse(inputs[4]);
            costA = int.Parse(inputs[5]);
            costB = int.Parse(inputs[6]);
            costC = int.Parse(inputs[7]);
            costD = int.Parse(inputs[8]);
            costE = int.Parse(inputs[9]);
                        
            if (carriedBy == 0)
            {
                player = Player.me;
                player.samples.Add(this);

                CalculateCost();
                CalculateMolecules();
            }
            else if (carriedBy == 1)
            {
                player = Player.enemy;
                player.samples.Add(this);
            }
        }

        public void CalculateCost()
        {
            totalCost =
                  costA - Player.me.expertiseA - Player.me.storageA
                + costB - Player.me.expertiseB - Player.me.storageB
                + costC - Player.me.expertiseC - Player.me.storageC
                + costD - Player.me.expertiseD - Player.me.storageD
                + costE - Player.me.expertiseE - Player.me.storageE;
        }

        public void CalculateMolecules()
        {
            molecules.Add(Molecule.a, costA - Player.me.storageA - Player.me.expertiseA);
            molecules.Add(Molecule.b, costB - Player.me.storageB - Player.me.expertiseB);
            molecules.Add(Molecule.c, costC - Player.me.storageC - Player.me.expertiseC);
            molecules.Add(Molecule.d, costD - Player.me.storageD - Player.me.expertiseD);
            molecules.Add(Molecule.e, costE - Player.me.storageE - Player.me.expertiseE);
        }

        public static void Initialize()
        {
            foreach (var sample in Sample.samples.Values)
            {
                
            }
        }

        public void PrintStats()
        {
            Console.Error.WriteLine("Sample " + id);
            Console.Error.WriteLine("Health: " + health);
            Console.Error.WriteLine("costA: " + costA);
            Console.Error.WriteLine("costB: " + costB);
            Console.Error.WriteLine("costC: " + costC);
            Console.Error.WriteLine("costD: " + costD);
            Console.Error.WriteLine("costE: " + costE);
            Console.Error.WriteLine("");
        }

        public static void CleanUp()
        {
            samples = new Dictionary<int, Sample>();
        }
    }
}

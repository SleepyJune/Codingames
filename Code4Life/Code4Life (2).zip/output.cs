
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] inputs;
            int projectCount = int.Parse(Console.ReadLine());
            for (int i = 0; i < projectCount; i++)
            {
                inputs = Console.ReadLine().Split(' ');
                int a = int.Parse(inputs[0]);
                int b = int.Parse(inputs[1]);
                int c = int.Parse(inputs[2]);
                int d = int.Parse(inputs[3]);
                int e = int.Parse(inputs[4]);
            }

            Player.me = new Player();
            Player.enemy = new Player();

            // game loop
            while (true)
            {
                for (int i = 0; i < 2; i++)
                {
                    inputs = Console.ReadLine().Split(' ');

                    
                    if (i == 0)
                    {
                        Player.me.ProcessInputs(inputs);
                    }
                    else
                    {
                        Player.enemy.ProcessInputs(inputs);
                    }
                }

                inputs = Console.ReadLine().Split(' ');
                Molecule.ProcessInputs(inputs);

                int sampleCount = int.Parse(Console.ReadLine());
                for (int i = 0; i < sampleCount; i++)
                {
                    inputs = Console.ReadLine().Split(' ');

                    Sample newSample = new Sample();
                    newSample.ProcessInputs(inputs);

                    Sample.samples.Add(newSample.id, newSample);                    
                }

                Game.InitializeTurn();
                Game.MakeMove();
                Game.PrintActions();
                Game.CleanUp();
            }
        }
    }

    class Game
    {
        public static int gameTurn = 0;

        public static void InitializeFirstTurn()
        {
            float loopStartTime = Timer.TickCount;

            
            float loopTime = Timer.TickCount - loopStartTime;
            //Console.Error.WriteLine("Initialization Time: " + loopTime);
        }

        public static void InitializeTurn()
        {
            Player.Initialize();
            Sample.Initialize();
        }

        public static void MakeMove()
        {
            Strategy.MakeMove();
        }

        public static void PrintActions()
        {
            Action.PrintActions();
        }

        public static void CleanUp()
        {
            Action.CleanUp();
            Player.CleanUp();
            Sample.CleanUp();

            gameTurn++;
        }
    }

    class Strategy
    {
        public static Random random = new Random();

        public static int[,] movementMatrix = new int[,]
        {
            {2,2,2,2},            
            {0,3,3,3},
            {3,0,3,4},
            {3,3,0,3},
            {3,4,3,0},
        };

        public static void MakeMove()
        {
            //Wait
            if (Player.me.eta > 0)
            {
                Action newAction = new Action(Player.me);
                Action.AddAction(newAction);
                return;
            }

            //Collect
            if (Player.me.module == Module.Start)
            {
                Action newAction = new Action(Player.me, Module.Samples);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Samples && Player.me.samples.Count < 3)
            {
                int exp = Player.me.CountExpertise();
                int rank = 1;

                if (exp > 3)
                {
                    rank = 2;
                }

                if (exp > 9)
                {
                    rank = 3;
                }
                

                Action newAction = new Action(Player.me, rank);
                Action.AddAction(newAction);
                return;                
            }

            Player.me.PrintPlayerStats();
            foreach (var sample in Player.me.samples)
            {
                sample.PrintStats();
            }

            //Analyze
            if (Player.me.module == Module.Samples)
            {
                Action newAction = new Action(Player.me, Module.Diagnosis);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Diagnosis)
            {
                //Console.Error.WriteLine(Player.me.samples.Count);

                foreach (var sample in Player.me.samples)//.OrderByDescending(s => s.health))
                {
                    if (sample.health == -1)
                    {
                        Action newAction = new Action(Player.me, sample);
                        Action.AddAction(newAction);
                        return;
                    }                    
                }
            }

            //Gather
            if (Player.me.module == Module.Diagnosis)
            {
                Action newAction = new Action(Player.me, Module.Molecules);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Molecules && Player.me.CountMolecules() < 10)
            {
                foreach (var sample in Player.me.samples.OrderBy(s => s.totalCost))
                {
                    if (!Player.me.hasEnoughMolecules(sample))
                    {
                        var missingMolecules = sample.molecules;

                        if (Molecule.canCompleteSample(missingMolecules) == false)
                        {
                            continue;
                        }

                        foreach (var pair in missingMolecules.OrderBy(p=>p.Key.count))
                        {                            
                            var molecule = pair.Key;
                            int count = pair.Value;

                            if (count > 0)
                            {
                                Action newAction = new Action(Player.me, molecule);
                                Action.AddAction(newAction);
                                return;
                            }
                        }
                    }
                    else
                    {
                        //break;
                    }
                    
                }
            }

            //Produce
            if (Player.me.module == Module.Molecules)
            {
                Action newAction = new Action(Player.me, Module.Laboratory);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Laboratory)
            {
                foreach (var sample in Player.me.samples.OrderByDescending(s => s.totalCost))
                {
                    if (Player.me.hasEnoughMolecules(sample))
                    {
                        Action newAction = new Action(Player.me, sample);
                        Action.AddAction(newAction);
                        return;
                    }

                }
            }

            //Go Back Collecting
            if (Player.me.module == Module.Laboratory)
            {
                if (Player.me.samples.Count > 0)
                {
                    Action newAction = new Action(Player.me, Module.Molecules);
                    Action.AddAction(newAction);
                    return;
                }
                else
                {
                    Action newAction = new Action(Player.me, Module.Samples);
                    Action.AddAction(newAction);
                    return;
                }
                
            }
        }
    }

    class Molecule
    {
        public static Molecule a = new Molecule("A");
        public static Molecule b = new Molecule("B");
        public static Molecule c = new Molecule("C");
        public static Molecule d = new Molecule("D");
        public static Molecule e = new Molecule("E");

        //public static Dictionary<string, Molecule> molecules = new Dictionary<string, Molecule>();

        public string name;
        public int count;

        public Molecule(string name)
        {
            this.name = name;
            //molecules.Add(name, this);
        }

        public static void ProcessInputs(string[] inputs)
        {
            Molecule.a.count = int.Parse(inputs[0]);
            Molecule.b.count = int.Parse(inputs[1]);
            Molecule.c.count = int.Parse(inputs[2]);
            Molecule.d.count = int.Parse(inputs[3]);
            Molecule.e.count = int.Parse(inputs[4]);
        }

        public static bool canCompleteSample(Dictionary<Molecule, int> missingMolecules)
        {
            return !missingMolecules.Any(p => p.Key.count < p.Value);
        }
    }

    class Player
    {
        public static Player me;
        public static Player enemy;
                
        public int eta;
        public int score;
        public int storageA;
        public int storageB;
        public int storageC;
        public int storageD;
        public int storageE;
        public int expertiseA;
        public int expertiseB;
        public int expertiseC;
        public int expertiseD;
        public int expertiseE;

        public List<Sample> samples;

        public Module module;

        public Player()
        {
            
        }

        public void ProcessInputs(string[] inputs)
        {
            eta = int.Parse(inputs[1]);
            score = int.Parse(inputs[2]);
            storageA = int.Parse(inputs[3]);
            storageB = int.Parse(inputs[4]);
            storageC = int.Parse(inputs[5]);
            storageD = int.Parse(inputs[6]);
            storageE = int.Parse(inputs[7]);
            expertiseA = int.Parse(inputs[8]);
            expertiseB = int.Parse(inputs[9]);
            expertiseC = int.Parse(inputs[10]);
            expertiseD = int.Parse(inputs[11]);
            expertiseE = int.Parse(inputs[12]);

            SetModule(inputs[0]);
        }

        public int CountExpertise()
        {
            return expertiseA + expertiseB + expertiseC + expertiseD + expertiseE;
        }

        public int CountMolecules()
        {
            return storageA + storageB + storageC + storageD + storageE;
        }

        public bool hasEnoughMolecules(Sample sample)
        {
            return !sample.molecules.Any(p=>p.Value > 0);
        }

        public void SetModule(string target)
        {
            if (target == "START_POS")
            {
                module = Module.Start;
            }
            else if (target == "SAMPLES")
            {
                module = Module.Samples;
            }
            else if (target == "DIAGNOSIS")
            {
                module = Module.Diagnosis;
            }
            else if (target == "MOLECULES")
            {
                module = Module.Molecules;
            }
            else if (target == "LABORATORY")
            {
                module = Module.Laboratory;
            }
        }

        public static void Initialize()
        {
            
        }

        public void PrintPlayerStats()
        {
            var player = this;

            Console.Error.WriteLine("Player");
            Console.Error.WriteLine("A: " + player.storageA);
            Console.Error.WriteLine("B: " + player.storageB);
            Console.Error.WriteLine("C: " + player.storageC);
            Console.Error.WriteLine("D: " + player.storageD);
            Console.Error.WriteLine("E: " + player.storageE);
            Console.Error.WriteLine("");
        }

        public static void CleanUp()
        {
            Player.me.samples = new List<Sample>();
            Player.enemy.samples = new List<Sample>();
        }
    }

    class Sample
    {
        public static Dictionary<int, Sample> samples = new Dictionary<int, Sample>();

        public int id;
        public int carriedBy;
        public int rank;
        public string expertiseGain;
        public int health;
        public int costA;
        public int costB;
        public int costC;
        public int costD;
        public int costE;

        public Dictionary<Molecule, int> molecules = new Dictionary<Molecule, int>();

        public int totalCost;

        public Player player = null;

        public Sample()
        {

        }

        public void ProcessInputs(string[] inputs)
        {
            id = int.Parse(inputs[0]);
            carriedBy = int.Parse(inputs[1]);
            rank = int.Parse(inputs[2]);
            expertiseGain = inputs[3];
            health = int.Parse(inputs[4]);
            costA = int.Parse(inputs[5]);
            costB = int.Parse(inputs[6]);
            costC = int.Parse(inputs[7]);
            costD = int.Parse(inputs[8]);
            costE = int.Parse(inputs[9]);
                        
            if (carriedBy == 0)
            {
                player = Player.me;
                player.samples.Add(this);

                CalculateCost();
                CalculateMolecules();
            }
            else if (carriedBy == 1)
            {
                player = Player.enemy;
                player.samples.Add(this);
            }
        }

        public void CalculateCost()
        {
            totalCost =
                  costA - Player.me.expertiseA - Player.me.storageA
                + costB - Player.me.expertiseB - Player.me.storageB
                + costC - Player.me.expertiseC - Player.me.storageC
                + costD - Player.me.expertiseD - Player.me.storageD
                + costE - Player.me.expertiseE - Player.me.storageE;
        }

        public void CalculateMolecules()
        {
            molecules.Add(Molecule.a, costA - Player.me.storageA - Player.me.expertiseA);
            molecules.Add(Molecule.b, costB - Player.me.storageB - Player.me.expertiseB);
            molecules.Add(Molecule.c, costC - Player.me.storageC - Player.me.expertiseC);
            molecules.Add(Molecule.d, costD - Player.me.storageD - Player.me.expertiseD);
            molecules.Add(Molecule.e, costE - Player.me.storageE - Player.me.expertiseE);
        }

        public static void Initialize()
        {
            foreach (var sample in Sample.samples.Values)
            {
                
            }
        }

        public void PrintStats()
        {
            Console.Error.WriteLine("Sample " + id);
            Console.Error.WriteLine("Health: " + health);
            Console.Error.WriteLine("costA: " + costA);
            Console.Error.WriteLine("costB: " + costB);
            Console.Error.WriteLine("costC: " + costC);
            Console.Error.WriteLine("costD: " + costD);
            Console.Error.WriteLine("costE: " + costE);
            Console.Error.WriteLine("");
        }

        public static void CleanUp()
        {
            samples = new Dictionary<int, Sample>();
        }
    }

    public enum MoveType
    {
        Goto,
        Connect,
        Wait,
    }

    public enum Module
    {
        Start,
        Samples,
        Diagnosis,
        Molecules,
        Laboratory,
    }

    class Action
    {
        public static List<Action> actions = new List<Action>();

        public MoveType move;
        public Module module;

        public Sample sample;
        public Molecule molecule;
        public Player player;
        public int rank;

        public Action(Player player)
        {
            this.move = MoveType.Wait;
            this.player = player;
        }

        public Action(Player player, Module module)
        {
            this.move = MoveType.Goto;
            this.player = player;
            this.module = module;
        }

        public Action(Player player, Sample sample)
        {
            this.move = MoveType.Connect;
            this.sample = sample;
            this.module = player.module;
        }

        public Action(Player player, Molecule molecule)
        {
            this.move = MoveType.Connect;
            this.molecule = molecule;
            this.module = player.module;
        }

        public Action(Player player, int rank)
        {
            this.move = MoveType.Connect;
            this.rank = rank;
            this.module = player.module;
        }

        public static void AddAction(Action action)
        {            
            Action.actions.Add(action);
        }

        public static void CleanUp()
        {
            actions = new List<Action>();
        }

        public static void PrintActions()
        {
            string str = "";

            foreach (var action in actions)
            {
                if (action.move == MoveType.Goto)
                {
                    str += "GOTO " + action.module.ToString().ToUpper();
                }
                else if (action.move == MoveType.Connect)
                {
                    if (action.module == Module.Molecules)
                    {
                        str += "CONNECT " + action.molecule.name;
                    }
                    else if (action.module == Module.Samples)
                    {
                        str += "CONNECT " + action.rank;
                    }
                    else
                    {                        
                        str += "CONNECT " + action.sample.id;
                    }
                }
                else if (action.move == MoveType.Wait)
                {
                    str += "WAIT";
                }

                break;
            }

            Console.WriteLine(str);
        }
    }

    class Timer
    {
        private static DateTime loadTime = DateTime.Now;

        public static float TickCount
        {
            get
            {
                return (int)DateTime.Now.Subtract(loadTime).TotalMilliseconds;
            }
        }
    }




}

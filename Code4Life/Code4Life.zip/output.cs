
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] inputs;
            int projectCount = int.Parse(Console.ReadLine());
            for (int i = 0; i < projectCount; i++)
            {
                inputs = Console.ReadLine().Split(' ');
                int a = int.Parse(inputs[0]);
                int b = int.Parse(inputs[1]);
                int c = int.Parse(inputs[2]);
                int d = int.Parse(inputs[3]);
                int e = int.Parse(inputs[4]);
            }

            Player.me = new Player();
            Player.enemy = new Player();

            // game loop
            while (true)
            {
                for (int i = 0; i < 2; i++)
                {
                    inputs = Console.ReadLine().Split(' ');

                    
                    if (i == 0)
                    {
                        Player.me.ProcessInputs(inputs);
                    }
                    else
                    {
                        Player.enemy.ProcessInputs(inputs);
                    }
                }

                inputs = Console.ReadLine().Split(' ');
                int availableA = int.Parse(inputs[0]);
                int availableB = int.Parse(inputs[1]);
                int availableC = int.Parse(inputs[2]);
                int availableD = int.Parse(inputs[3]);
                int availableE = int.Parse(inputs[4]);

                int sampleCount = int.Parse(Console.ReadLine());
                for (int i = 0; i < sampleCount; i++)
                {
                    inputs = Console.ReadLine().Split(' ');

                    Sample newSample = new Sample();
                    newSample.ProcessInputs(inputs);

                    Sample.samples.Add(newSample.id, newSample);                    
                }

                Game.InitializeTurn();
                Game.MakeMove();
                Game.PrintActions();
                Game.CleanUp();
            }
        }
    }

    class Game
    {
        public static int gameTurn = 0;

        public static void InitializeFirstTurn()
        {
            float loopStartTime = Timer.TickCount;

            
            float loopTime = Timer.TickCount - loopStartTime;
            //Console.Error.WriteLine("Initialization Time: " + loopTime);
        }

        public static void InitializeTurn()
        {
            Player.Initialize();
            Sample.Initialize();
        }

        public static void MakeMove()
        {
            Strategy.MakeMove();
        }

        public static void PrintActions()
        {
            Action.PrintActions();
        }

        public static void CleanUp()
        {
            Action.CleanUp();
            Player.CleanUp();
            Sample.CleanUp();

            gameTurn++;
        }
    }

    class Strategy
    {
        public static Random random = new Random();

        public static void MakeMove()
        {
            //Collect
            if (Player.me.module == Module.Start)
            {
                Action newAction = new Action(Player.me, Module.Samples);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Samples && Player.me.samples.Count < 3)
            {
                Action newAction = new Action(Player.me, 1);
                Action.AddAction(newAction);
                return;                
            }

            /*Player.me.PrintPlayerStats();
            foreach (var sample in Player.me.samples)
            {
                sample.PrintStats();
            }*/

            //Analyze
            if (Player.me.module == Module.Samples)
            {
                Action newAction = new Action(Player.me, Module.Diagnosis);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Diagnosis)
            {
                //Console.Error.WriteLine(Player.me.samples.Count);

                foreach (var sample in Player.me.samples)//.OrderByDescending(s => s.health))
                {
                    if (sample.health == -1)
                    {
                        Action newAction = new Action(Player.me, sample);
                        Action.AddAction(newAction);
                        return;
                    }                    
                }
            }

            //Gather
            if (Player.me.module == Module.Diagnosis)
            {
                Action newAction = new Action(Player.me, Module.Molecules);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Molecules && Player.me.CountMolecules() < 10)
            {
                foreach (var sample in Player.me.samples.OrderByDescending(s => s.health))
                {
                    if (!Player.me.hasEnoughMolecules(sample))
                    {
                        var missingMolecules = Player.me.missingMolecules(sample);
                        foreach (var pair in missingMolecules)
                        {
                            var molecule = pair.Key;
                            int count = pair.Value;

                            Action newAction = new Action(Player.me, molecule);
                            Action.AddAction(newAction);
                            return;
                        }
                    }
                    else
                    {
                        break;
                    }
                    
                }
            }

            //Produce
            if (Player.me.module == Module.Molecules)
            {
                Action newAction = new Action(Player.me, Module.Laboratory);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Laboratory)
            {
                foreach (var sample in Player.me.samples.OrderByDescending(s => s.health))
                {
                    if (Player.me.hasEnoughMolecules(sample))
                    {
                        Action newAction = new Action(Player.me, sample);
                        Action.AddAction(newAction);
                        return;
                    }

                }
            }

            //Go Back Collecting
            if (Player.me.module == Module.Laboratory)
            {
                Action newAction = new Action(Player.me, Module.Samples);
                Action.AddAction(newAction);
                return;
            }
        }
    }

    class Molecule
    {
        public static Molecule a = new Molecule("A");
        public static Molecule b = new Molecule("B");
        public static Molecule c = new Molecule("C");
        public static Molecule d = new Molecule("D");
        public static Molecule e = new Molecule("E");

        public string name;

        public Molecule(string name)
        {
            this.name = name;
        }
    }

    class Player
    {
        public static Player me;
        public static Player enemy;
                
        public int eta;
        public int score;
        public int storageA;
        public int storageB;
        public int storageC;
        public int storageD;
        public int storageE;
        public int expertiseA;
        public int expertiseB;
        public int expertiseC;
        public int expertiseD;
        public int expertiseE;

        public List<Sample> samples;

        public Module module;

        public Player()
        {
            
        }

        public void ProcessInputs(string[] inputs)
        {
            eta = int.Parse(inputs[1]);
            score = int.Parse(inputs[2]);
            storageA = int.Parse(inputs[3]);
            storageB = int.Parse(inputs[4]);
            storageC = int.Parse(inputs[5]);
            storageD = int.Parse(inputs[6]);
            storageE = int.Parse(inputs[7]);
            expertiseA = int.Parse(inputs[8]);
            expertiseB = int.Parse(inputs[9]);
            expertiseC = int.Parse(inputs[10]);
            expertiseD = int.Parse(inputs[11]);
            expertiseE = int.Parse(inputs[12]);

            SetModule(inputs[0]);
        }

        public int CountMolecules()
        {
            return storageA + storageB + storageC + storageD + storageE;
        }

        public bool hasEnoughMolecules(Sample sample)
        {
            return storageA >= sample.costA 
                && storageB >= sample.costB 
                && storageC >= sample.costC
                && storageD >= sample.costD
                && storageE >= sample.costE;
        }

        public Dictionary<Molecule, int> missingMolecules(Sample sample)
        {
            Dictionary<Molecule, int> samples = new Dictionary<Molecule,int>();

            if(storageA < sample.costA){
                samples.Add(Molecule.a,sample.costA-storageA);
            }
            if(storageB < sample.costB){
                samples.Add(Molecule.b,sample.costB-storageB);
            }
            if(storageC < sample.costC){
                samples.Add(Molecule.c,sample.costC-storageC);
            }
            if(storageD < sample.costD){
                samples.Add(Molecule.d,sample.costD-storageD);
            }
            if(storageE < sample.costE){
                samples.Add(Molecule.e,sample.costE-storageE);
            }

            return samples;
        }

        public void SetModule(string target)
        {
            if (target == "START_POS")
            {
                module = Module.Start;
            }
            else if (target == "SAMPLES")
            {
                module = Module.Samples;
            }
            else if (target == "DIAGNOSIS")
            {
                module = Module.Diagnosis;
            }
            else if (target == "MOLECULES")
            {
                module = Module.Molecules;
            }
            else if (target == "LABORATORY")
            {
                module = Module.Laboratory;
            }
        }

        public static void Initialize()
        {
            
        }

        public void PrintPlayerStats()
        {
            var player = this;

            Console.Error.WriteLine("Player");
            Console.Error.WriteLine("A: " + player.storageA);
            Console.Error.WriteLine("B: " + player.storageB);
            Console.Error.WriteLine("C: " + player.storageC);
            Console.Error.WriteLine("D: " + player.storageD);
            Console.Error.WriteLine("E: " + player.storageE);
            Console.Error.WriteLine("");
        }

        public static void CleanUp()
        {
            Player.me.samples = new List<Sample>();
            Player.enemy.samples = new List<Sample>();
        }
    }

    class Sample
    {
        public static Dictionary<int, Sample> samples = new Dictionary<int, Sample>();

        public int id;
        public int carriedBy;
        public int rank;
        public string expertiseGain;
        public int health;
        public int costA;
        public int costB;
        public int costC;
        public int costD;
        public int costE;

        public Player player = null;

        public Sample()
        {

        }

        public void ProcessInputs(string[] inputs)
        {
            id = int.Parse(inputs[0]);
            carriedBy = int.Parse(inputs[1]);
            rank = int.Parse(inputs[2]);
            expertiseGain = inputs[3];
            health = int.Parse(inputs[4]);
            costA = int.Parse(inputs[5]);
            costB = int.Parse(inputs[6]);
            costC = int.Parse(inputs[7]);
            costD = int.Parse(inputs[8]);
            costE = int.Parse(inputs[9]);

            if (carriedBy == 0)
            {
                player = Player.me;
                player.samples.Add(this);
            }
            else if (carriedBy == 1)
            {
                player = Player.enemy;
                player.samples.Add(this);
            }
        }

        public static void Initialize()
        {
            foreach (var sample in Sample.samples.Values)
            {
                
            }
        }

        public void PrintStats()
        {
            Console.Error.WriteLine("Sample " + id);
            Console.Error.WriteLine("Health: " + health);
            Console.Error.WriteLine("costA: " + costA);
            Console.Error.WriteLine("costB: " + costB);
            Console.Error.WriteLine("costC: " + costC);
            Console.Error.WriteLine("costD: " + costD);
            Console.Error.WriteLine("costE: " + costE);
            Console.Error.WriteLine("");
        }

        public static void CleanUp()
        {
            samples = new Dictionary<int, Sample>();
        }
    }

    public enum MoveType
    {
        Goto,
        Connect,
    }

    public enum Module
    {
        Start,
        Samples,
        Diagnosis,
        Molecules,
        Laboratory,
    }

    class Action
    {
        public static List<Action> actions = new List<Action>();

        public MoveType move;
        public Module module;

        public Sample sample;
        public Molecule molecule;
        public Player player;
        public int rank;

        public Action(Player player, Module module)
        {
            this.move = MoveType.Goto;
            this.player = player;
            this.module = module;
        }

        public Action(Player player, Sample sample)
        {
            this.move = MoveType.Connect;
            this.sample = sample;
            this.module = player.module;
        }

        public Action(Player player, Molecule molecule)
        {
            this.move = MoveType.Connect;
            this.molecule = molecule;
            this.module = player.module;
        }

        public Action(Player player, int rank)
        {
            this.move = MoveType.Connect;
            this.rank = rank;
            this.module = player.module;
        }

        public static void AddAction(Action action)
        {            
            Action.actions.Add(action);
        }

        public static void CleanUp()
        {
            actions = new List<Action>();
        }

        public static void PrintActions()
        {
            string str = "";

            foreach (var action in actions)
            {
                if (action.move == MoveType.Goto)
                {
                    str += "GOTO " + action.module.ToString().ToUpper();
                }
                else if (action.move == MoveType.Connect)
                {
                    if (action.module == Module.Molecules)
                    {
                        str += "CONNECT " + action.molecule.name;
                    }
                    else if (action.module == Module.Samples)
                    {
                        str += "CONNECT " + action.rank;
                    }
                    else
                    {                        
                        str += "CONNECT " + action.sample.id;
                    }
                }

                break;
            }

            Console.WriteLine(str);
        }
    }

    class Timer
    {
        private static DateTime loadTime = DateTime.Now;

        public static float TickCount
        {
            get
            {
                return (int)DateTime.Now.Subtract(loadTime).TotalMilliseconds;
            }
        }
    }




}

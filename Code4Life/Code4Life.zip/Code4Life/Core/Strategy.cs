﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Strategy
    {
        public static Random random = new Random();

        public static void MakeMove()
        {
            //Collect
            if (Player.me.module == Module.Start)
            {
                Action newAction = new Action(Player.me, Module.Samples);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Samples && Player.me.samples.Count < 3)
            {
                Action newAction = new Action(Player.me, 1);
                Action.AddAction(newAction);
                return;                
            }

            /*Player.me.PrintPlayerStats();
            foreach (var sample in Player.me.samples)
            {
                sample.PrintStats();
            }*/

            //Analyze
            if (Player.me.module == Module.Samples)
            {
                Action newAction = new Action(Player.me, Module.Diagnosis);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Diagnosis)
            {
                //Console.Error.WriteLine(Player.me.samples.Count);

                foreach (var sample in Player.me.samples)//.OrderByDescending(s => s.health))
                {
                    if (sample.health == -1)
                    {
                        Action newAction = new Action(Player.me, sample);
                        Action.AddAction(newAction);
                        return;
                    }                    
                }
            }

            //Gather
            if (Player.me.module == Module.Diagnosis)
            {
                Action newAction = new Action(Player.me, Module.Molecules);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Molecules && Player.me.CountMolecules() < 10)
            {
                foreach (var sample in Player.me.samples.OrderByDescending(s => s.health))
                {
                    if (!Player.me.hasEnoughMolecules(sample))
                    {
                        var missingMolecules = Player.me.missingMolecules(sample);
                        foreach (var pair in missingMolecules)
                        {
                            var molecule = pair.Key;
                            int count = pair.Value;

                            Action newAction = new Action(Player.me, molecule);
                            Action.AddAction(newAction);
                            return;
                        }
                    }
                    else
                    {
                        break;
                    }
                    
                }
            }

            //Produce
            if (Player.me.module == Module.Molecules)
            {
                Action newAction = new Action(Player.me, Module.Laboratory);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Laboratory)
            {
                foreach (var sample in Player.me.samples.OrderByDescending(s => s.health))
                {
                    if (Player.me.hasEnoughMolecules(sample))
                    {
                        Action newAction = new Action(Player.me, sample);
                        Action.AddAction(newAction);
                        return;
                    }

                }
            }

            //Go Back Collecting
            if (Player.me.module == Module.Laboratory)
            {
                Action newAction = new Action(Player.me, Module.Samples);
                Action.AddAction(newAction);
                return;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Game
    {
        public static int gameTurn = 0;

        public static void InitializeFirstTurn()
        {
            float loopStartTime = Timer.TickCount;

            
            float loopTime = Timer.TickCount - loopStartTime;
            //Console.Error.WriteLine("Initialization Time: " + loopTime);
        }

        public static void InitializeTurn()
        {
            Player.Initialize();
            Sample.Initialize();
        }

        public static void MakeMove()
        {
            Strategy.MakeMove();
        }

        public static void PrintActions()
        {
            Action.PrintActions();
        }

        public static void CleanUp()
        {
            Action.CleanUp();
            Player.CleanUp();
            Sample.CleanUp();

            gameTurn++;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Molecule
    {
        public static Molecule a = new Molecule("A");
        public static Molecule b = new Molecule("B");
        public static Molecule c = new Molecule("C");
        public static Molecule d = new Molecule("D");
        public static Molecule e = new Molecule("E");

        public string name;

        public Molecule(string name)
        {
            this.name = name;
        }
    }
}

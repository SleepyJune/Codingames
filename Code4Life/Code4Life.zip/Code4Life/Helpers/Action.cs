﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    public enum MoveType
    {
        Goto,
        Connect,
    }

    public enum Module
    {
        Start,
        Samples,
        Diagnosis,
        Molecules,
        Laboratory,
    }

    class Action
    {
        public static List<Action> actions = new List<Action>();

        public MoveType move;
        public Module module;

        public Sample sample;
        public Molecule molecule;
        public Player player;
        public int rank;

        public Action(Player player, Module module)
        {
            this.move = MoveType.Goto;
            this.player = player;
            this.module = module;
        }

        public Action(Player player, Sample sample)
        {
            this.move = MoveType.Connect;
            this.sample = sample;
            this.module = player.module;
        }

        public Action(Player player, Molecule molecule)
        {
            this.move = MoveType.Connect;
            this.molecule = molecule;
            this.module = player.module;
        }

        public Action(Player player, int rank)
        {
            this.move = MoveType.Connect;
            this.rank = rank;
            this.module = player.module;
        }

        public static void AddAction(Action action)
        {            
            Action.actions.Add(action);
        }

        public static void CleanUp()
        {
            actions = new List<Action>();
        }

        public static void PrintActions()
        {
            string str = "";

            foreach (var action in actions)
            {
                if (action.move == MoveType.Goto)
                {
                    str += "GOTO " + action.module.ToString().ToUpper();
                }
                else if (action.move == MoveType.Connect)
                {
                    if (action.module == Module.Molecules)
                    {
                        str += "CONNECT " + action.molecule.name;
                    }
                    else if (action.module == Module.Samples)
                    {
                        str += "CONNECT " + action.rank;
                    }
                    else
                    {                        
                        str += "CONNECT " + action.sample.id;
                    }
                }

                break;
            }

            Console.WriteLine(str);
        }
    }
}

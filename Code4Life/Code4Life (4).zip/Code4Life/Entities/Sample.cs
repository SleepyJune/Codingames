﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Sample
    {
        public static Dictionary<int, Sample> samples = new Dictionary<int, Sample>();

        public Dictionary<Molecule, int> costs = new Dictionary<Molecule, int>();

        public int id;
        public int carriedBy;
        public int rank;
        public string expertiseGain;
        public int health;
        public int costA;
        public int costB;
        public int costC;
        public int costD;
        public int costE;

        public Dictionary<Molecule, int> molecules = new Dictionary<Molecule, int>();
        public Dictionary<Molecule, int> enemyMolecules = new Dictionary<Molecule, int>();

        public int totalCost;

        public Player player = null;

        public Sample()
        {

        }

        public void ProcessInputs(string[] inputs)
        {
            id = int.Parse(inputs[0]);
            carriedBy = int.Parse(inputs[1]);
            rank = int.Parse(inputs[2]);
            expertiseGain = inputs[3];
            health = int.Parse(inputs[4]);
            costA = int.Parse(inputs[5]);
            costB = int.Parse(inputs[6]);
            costC = int.Parse(inputs[7]);
            costD = int.Parse(inputs[8]);
            costE = int.Parse(inputs[9]);

            costs.Add(Molecule.a, costA);
            costs.Add(Molecule.b, costB);
            costs.Add(Molecule.c, costC);
            costs.Add(Molecule.d, costD);
            costs.Add(Molecule.e, costE);

            if (carriedBy == 0)
            {
                player = Player.me;
                player.samples.Add(this);

                CalculateCost();                
            }
            else if (carriedBy == 1)
            {
                player = Player.enemy;
                player.samples.Add(this);                
            }

            if (health != -1)
            {
                CalculateMolecules();
                CalculateEnemyMolecules();
            }
        }

        public static List<Sample> GetAvailableSamples()
        {
            List<Sample> newList = new List<Sample>(Player.me.samples);
            newList.AddRange(samples.Values.Where(s => s.carriedBy == -1));

            return newList;
        }

        public bool canResearch()
        {
            return canResearch(Player.me);
        }

        public bool canResearch(Player player)
        {
            return !costs.Any(p => p.Value - player.expertises[p.Key] - player.storages[p.Key] > 5);//p.Key.count);
        }

        public bool hardToResearch()
        {
            var pair = this.molecules.OrderByDescending(p => p.Value).First();
            var molecule = pair.Key;
            var count = pair.Value;
            if (count >= 4)
            {
                if (Player.me.samples.Any(s => s.id != this.id && s.costs[molecule] >= count))
                {
                    return true;
                }
            }

            return costs.Any(p => p.Value > 4 && p.Value - Player.me.expertises[p.Key] - Player.me.storages[p.Key] >= p.Key.count);
        }

        public void CalculateCost()
        {
            totalCost =
                  costA - Player.me.expertiseA - Player.me.storageA
                + costB - Player.me.expertiseB - Player.me.storageB
                + costC - Player.me.expertiseC - Player.me.storageC
                + costD - Player.me.expertiseD - Player.me.storageD
                + costE - Player.me.expertiseE - Player.me.storageE;
        }

        public void CalculateMolecules()
        {
            molecules.Add(Molecule.a, costA - Player.me.storageA - Player.me.expertiseA);
            molecules.Add(Molecule.b, costB - Player.me.storageB - Player.me.expertiseB);
            molecules.Add(Molecule.c, costC - Player.me.storageC - Player.me.expertiseC);
            molecules.Add(Molecule.d, costD - Player.me.storageD - Player.me.expertiseD);
            molecules.Add(Molecule.e, costE - Player.me.storageE - Player.me.expertiseE);            
        }

        public void CalculateEnemyMolecules()
        {
            enemyMolecules.Add(Molecule.a, costA - Player.enemy.storageA - Player.enemy.expertiseA);
            enemyMolecules.Add(Molecule.b, costB - Player.enemy.storageB - Player.enemy.expertiseB);
            enemyMolecules.Add(Molecule.c, costC - Player.enemy.storageC - Player.enemy.expertiseC);
            enemyMolecules.Add(Molecule.d, costD - Player.enemy.storageD - Player.enemy.expertiseD);
            enemyMolecules.Add(Molecule.e, costE - Player.enemy.storageE - Player.enemy.expertiseE);
        }

        public Dictionary<Molecule, int> CalculateMolecules(GameState state)
        {
            var moles = new Dictionary<Molecule, int>();
            moles.Add(Molecule.a, (int)Math.Max(0, costA - state.expertiseA - state.storageA + state.reservedA));
            moles.Add(Molecule.b, (int)Math.Max(0, costB - state.expertiseB - state.storageB + state.reservedB));
            moles.Add(Molecule.c, (int)Math.Max(0, costC - state.expertiseC - state.storageC + state.reservedC));
            moles.Add(Molecule.d, (int)Math.Max(0, costD - state.expertiseD - state.storageD + state.reservedD));
            moles.Add(Molecule.e, (int)Math.Max(0, costE - state.expertiseE - state.storageE + state.reservedE));

            return moles;
        }

        public static void Initialize()
        {
            foreach (var sample in Sample.samples.Values)
            {

            }
        }

        public void PrintStats()
        {
            Console.Error.WriteLine("Sample " + id);
            //Console.Error.WriteLine("Health: " + health);
            Console.Error.WriteLine("costA: " + costA);
            Console.Error.WriteLine("costB: " + costB);
            Console.Error.WriteLine("costC: " + costC);
            Console.Error.WriteLine("costD: " + costD);
            Console.Error.WriteLine("costE: " + costE);
            Console.Error.WriteLine("Gain: " + expertiseGain);
            Console.Error.WriteLine("");
        }

        public static void CleanUp()
        {
            samples = new Dictionary<int, Sample>();
        }
    }
}

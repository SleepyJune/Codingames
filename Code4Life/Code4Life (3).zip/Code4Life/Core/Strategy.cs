﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Strategy
    {
        public static Random random = new Random();

        public static int[,] movementMatrix = new int[,]
        {
            {2,2,2,2},            
            {0,3,3,3},
            {3,0,3,4},
            {3,3,0,3},
            {3,4,3,0},
        };

        public static void MakeMove()
        {
            //Wait
            if (Player.me.eta > 0)
            {
                Action newAction = new Action();
                Action.AddAction(newAction);
                return;
            }

            //Collect
            if (Player.me.module == Module.Start)
            {
                Action newAction = new Action(Module.Samples);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Samples && Player.me.samples.Count < 3)
            {
                int exp = Player.me.CountExpertise();
                int rank = 1;

                if (exp >= 3)
                {
                    rank = 2;
                }

                if (exp > 9)
                {
                    rank = 3;
                }


                Action newAction = new Action(rank);
                Action.AddAction(newAction);
                return;
            }

            Player.me.PrintPlayerStats();
            foreach (var sample in Player.me.samples)
            {
                sample.PrintStats();
            }

            //Analyze
            if (Player.me.module == Module.Samples)
            {
                Action newAction = new Action(Module.Diagnosis);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Diagnosis)
            {
                //Console.Error.WriteLine(Player.me.samples.Count);

                foreach (var sample in Player.me.samples)
                {
                    if (sample.health == -1)
                    {
                        Action newAction = new Action(sample);
                        Action.AddAction(newAction);
                        return;
                    }
                    else
                    {
                        /*if (sample.canResearch() == false)
                        {
                            Action newAction = new Action(sample);
                            Action.AddAction(newAction);
                            return;
                        }*/
                    }
                }

                if (Player.me.samples.Count <= 1)
                {
                    Action newAction = new Action(Module.Samples);
                    Action.AddAction(newAction);
                    return;
                }
            }

            //Gather
            if (Player.me.module == Module.Diagnosis)
            {
                Action newAction = new Action(Module.Molecules);
                Action.AddAction(newAction);
                return;
            }

            if (Player.me.module == Module.Molecules && Player.me.CountMolecules() < 10)
            {
                int completedSample = 0;

                var combinations = SampleOptimization.TrySampleCombinations(new GameState(Player.me), Player.me.samples, new List<Sample>());

                if (combinations.Count > 0)
                {
                    foreach (var combination in combinations)
                    {

                        var samples = combination.samples;
                        foreach (var sample in samples)
                        {
                            Console.Error.Write(sample.id + " => ");
                        }

                        combination.state.PrintStateStats();
                        Console.Error.WriteLine("");
                    }

                    var bestCombination =
                        combinations
                        .OrderByDescending(c => c.samples.Count)
                        .ThenBy(c => c.state.CountMolecules()).First();

                    Console.Error.WriteLine("Best: ");
                    foreach (var sample in bestCombination.samples)
                    {
                        Console.Error.Write(sample.id + " => ");
                    }
                    Console.Error.WriteLine("");

                    Player.me.bestCombination = bestCombination;

                    var missingMolecules = bestCombination.CalculateMolecules();

                    foreach (var pair in missingMolecules.OrderByDescending(p => p.Key.myCount))
                    {
                        var molecule = pair.Key;
                        int count = pair.Value;

                        if (count > 0)
                        {
                            Action newAction = new Action(molecule);
                            Action.AddAction(newAction);
                            return;
                        }
                    }

                    /*foreach (var molecule in Molecule.molecules.Values.OrderBy(m=>m.count))
                    {
                        if (molecule.count > 0)
                        {
                            Action newAction = new Action(molecule);
                            Action.AddAction(newAction);
                            return;
                        }
                    }*/


                }
                else
                {
                    Player.me.bestCombination = null;
                }

                if (Player.me.module == Module.Molecules)
                {
                    if (!Player.me.samples.Any(s => Player.me.hasEnoughMolecules(s)))
                    {
                        if (Player.me.samples.Count <= 1)
                        {
                            Action newAction = new Action(Module.Samples);
                            Action.AddAction(newAction);
                            return;
                        }
                        else
                        {
                            Action newAction = new Action(Module.Diagnosis);
                            Action.AddAction(newAction);
                            return;
                        }
                    }
                }

                /*foreach (var sample in Player.me.samples.OrderBy(s => s.totalCost))
                {
                    if (!Player.me.hasEnoughMolecules(sample))
                    {
                        var missingMolecules = sample.molecules;

                        if (Molecule.canCompleteSample(missingMolecules) == false)
                        {
                            continue;
                        }

                        foreach (var pair in missingMolecules.OrderBy(p=>p.Key.count))
                        {                            
                            var molecule = pair.Key;
                            int count = pair.Value;

                            if (count > 0)
                            {
                                Action newAction = new Action(molecule);
                                Action.AddAction(newAction);
                                return;
                            }
                        }
                    }
                    else
                    {
                        completedSample++;    
                    }                                                        
                }*/

                /*if (Player.me.samples.Count == 1 && Player.me.hasEnoughMolecules(Player.me.samples.First()))
                {
                    foreach (var molecule in Molecule.molecules.Values.OrderBy(m=>m.count))
                    {
                        if (molecule.count > 0)
                        {
                            Action newAction = new Action(Player.me, molecule);
                            Action.AddAction(newAction);
                            return;
                        }
                    }
                }*/
            }

            //Produce
            if (Player.me.module == Module.Molecules)
            {
                if (false)//Player.me.samples.Count == 1)
                {
                    Action newAction = new Action(Module.Samples);
                    Action.AddAction(newAction);
                    return;
                }
                else
                {
                    Action newAction = new Action(Module.Laboratory);
                    Action.AddAction(newAction);
                    return;
                }
            }

            if (Player.me.module == Module.Laboratory)
            {
                if (Player.me.bestCombination != null)//Player.me.bestCombination.samples.All(s => Player.me.samples.Contains(s))
                {
                    foreach (var tSample in Player.me.bestCombination.samples)
                    {
                        var sample = Player.me.samples.FirstOrDefault(s => s.id == tSample.id);

                        if (sample != null && Player.me.hasEnoughMolecules(sample))
                        {
                            Action newAction = new Action(sample);
                            Action.AddAction(newAction);
                            return;
                        }
                    }
                }
                else
                {
                    foreach (var sample in Player.me.samples.OrderByDescending(s => s.totalCost))
                    {
                        if (Player.me.hasEnoughMolecules(sample))
                        {
                            Action newAction = new Action(sample);
                            Action.AddAction(newAction);
                            return;
                        }

                    }
                }
            }

            //Go Back Collecting
            if (Player.me.module == Module.Laboratory)
            {
                if (Player.me.samples.Count > 1 && Player.me.samples.Any(s => Molecule.canCompleteSample(s.molecules)))
                {
                    Action newAction = new Action(Module.Molecules);
                    Action.AddAction(newAction);
                    return;
                }
                else if (Player.me.samples.Count < 3)
                {
                    Action newAction = new Action(Module.Samples);
                    Action.AddAction(newAction);
                    return;
                }

            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code4Life
{
    class Strategy
    {
        public static Random random = new Random();

        public static int[,] movementMatrix = new int[,]
        {
            {2,2,2,2},            
            {0,3,3,3},
            {3,0,3,4},
            {3,3,0,3},
            {3,4,3,0},
        };

        public static double[] rankAverageMolecules = new double[]
        {
            4,6.5,10.5
        };

        public static bool MoveWait()
        {
            //Wait
            if (Player.me.eta > 0)
            {
                Action newAction = new Action();
                Action.AddAction(newAction);
                return false;
            }

            //Game ending
            /*if (200 - Game.gameTurn < 25)
            {
                //var finalSamples = Player.enemy.samples;

                if (Player.me.score > Player.enemy.score)
                {
                    if (Player.me.module == Module.Samples
                        || Player.me.module == Module.Diagnosis)
                    {
                        Action newAction = new Action(Module.Molecules);
                        Action.AddAction(newAction);
                        return false;
                    }
                }
            }*/

            return true;
        }

        public static bool Collect()
        {
            //Collect
            if (Player.me.module == Module.Start)
            {
                Action newAction = new Action(Module.Samples);
                Action.AddAction(newAction);
                return false;
            }

            var completedSamplesAvailable = Sample.samples.Values.Where(s => s.carriedBy == -1 && s.isCompleted()).Count();
            if (Player.me.module == Module.Samples && Player.me.samples.Count + completedSamplesAvailable < 3)
            {
                int exp = Player.me.CountExpertise();
                double sampleMolecules = Player.me.samples.Sum(s => rankAverageMolecules[s.rank - 1]);
                int samplesLeft = 3 - Player.me.samples.Count;

                int rank = 1;

                /*rank = (int)Math.Floor((12 - sampleMolecules + samplesLeft * exp) / 3.5 / samplesLeft);
                
                Console.Error.WriteLine(rank);
                
                rank = Math.Min(3, Math.Max(1, rank));*/

                if (exp >= 6)
                {
                    rank = 2;
                }

                /*if (exp >= 9)
                {
                    rank = 3;
                }*/

                if (exp >= 12 && Player.me.CountMolecules() == 0)
                {
                    if(Player.enemy.module == Module.Molecules ||
                        Player.enemy.module == Module.Laboratory)
                    {
                        rank = 3;
                    }
                }

                var turnsLeft = 200 - Game.gameTurn;
                Console.Error.WriteLine(turnsLeft);
                if (turnsLeft < 50)
                {
                    rank = 2;

                    //if i can finish projects
                    /*if (ScienceProject.projects.Any(p => p.GetPointsLeft() < 3))
                    {
                        rank = 1;
                    }*/
                }

                Action newAction = new Action(rank);
                Action.AddAction(newAction);
                return false;
            }

            return true;
        }

        public static bool Analyze()
        {
            //Analyze
            if (Player.me.module == Module.Samples)
            {
                Action newAction = new Action(Module.Diagnosis);
                Action.AddAction(newAction);
                return false;
            }

            if (Player.me.module == Module.Diagnosis)
            {
                //Console.Error.WriteLine(Player.me.samples.Count);

                //getting samples from cloud
                if (Player.me.samples.Count < 3)
                {
                    foreach (var sample in Sample.samples.Values
                                                .Where(s => s.carriedBy == -1)
                                                .OrderByDescending(s => s.isCompleted()))
                    {
                        if (!sample.hardToResearch() && sample.canCompleteSample())
                        {
                            Action newAction = new Action(sample);
                            Action.AddAction(newAction);
                            return false;
                        }
                        else if (sample.isCompleted())
                        {
                            Action newAction = new Action(sample);
                            Action.AddAction(newAction);
                            return false;
                        }
                    }
                }

                //analyze undiagnosed samples
                foreach (var sample in Player.me.samples)
                {
                    if (sample.health == -1)
                    {
                        Action newAction = new Action(sample);
                        Action.AddAction(newAction);
                        return false;
                    }
                    else
                    {
                        if (!sample.canResearch())//if (sample.hardToResearch())
                        {
                            Action newAction = new Action(sample);
                            Action.AddAction(newAction);
                            return false;
                        }
                    }
                }

                //remove hard to research samples
                /*foreach (var sample in Player.me.samples.OrderByDescending(s => s.costs.Max(m => m.Value))
                                                        .ThenBy(s => s.costs.Sum(m => m.Value)))
                {
                    var pair = sample.molecules.OrderByDescending(p => p.Value).First();
                    var molecule = pair.Key;
                    var count = pair.Value;
                    if (count >= 4)
                    {
                        if (Player.me.samples.Any(s => s.id != sample.id && s.costs[molecule] >= count))
                        {
                            Action newAction = new Action(sample);
                            Action.AddAction(newAction);
                            return;
                        }
                    }
                }*/


                if (!Player.me.samples.Any(s => s.canCompleteSample()) && Player.me.samples.Count > 1)
                {
                    foreach (var sample in Player.me.samples.OrderByDescending(s => s.costs.Max(m => m.Value)))
                    {
                        Action newAction = new Action(sample);
                        Action.AddAction(newAction);
                        return false;
                    }
                }

                if (Player.me.samples.Count <= 1)
                {
                    Action newAction = new Action(Module.Samples);
                    Action.AddAction(newAction);
                    return false;
                }
            }

            if (Player.me.module == Module.Diagnosis)
            {
                Action newAction = new Action(Module.Molecules);
                Action.AddAction(newAction);
                return false;
            }

            return true;
        }

        public static bool Gather()
        {
            //Gather

            if (Player.me.module == Module.Molecules && Player.me.CountMolecules() < 10)
            {
                //Game ending stop enemy
                //test test
                /*if (200 - Game.gameTurn < 25)
                {
                    foreach (var sample in Player.enemy.samples
                        .OrderByDescending(s => s.costs.Max(p => p.Value - Player.enemy.expertises[p.Key] - Player.enemy.storages[p.Key])))
                    {
                        if (sample.canResearch())
                        {
                            foreach (var pair in sample.costs.OrderBy(p => p.Value))
                            {
                                var molecule = pair.Key;
                                int count = pair.Value;

                                if (molecule.count > 0)
                                {
                                    Action newAction = new Action(molecule);
                                    Action.AddAction(newAction);
                                    return false;
                                }
                            }
                        }
                    }
                }*/

                //Stop enemy sample
                foreach (var sample in Player.enemy.samples)
                {
                    if (sample.canResearch())
                    {
                        foreach (var pair in sample.costs.Where(p => p.Value - Player.enemy.expertises[p.Key] - Player.enemy.storages[p.Key] == p.Key.count))
                        {
                            var molecule = pair.Key;
                            int count = pair.Value;

                            if (count > 4 && molecule.count > 0)
                            {
                                Action newAction = new Action(molecule);
                                Action.AddAction(newAction);
                                return false;
                            }
                        }
                    }
                }

                var combinations = SampleOptimization.TrySampleCombinations(new GameState(Player.me), Player.me.samples, new List<Sample>());
                if (combinations.Count > 0)
                {
                    var bestCombination =
                        combinations
                        .OrderByDescending(c => c.samples.Count)
                        .ThenBy(c => c.state.CountMolecules()).First();

                    //if enemy is already at lab
                    if (Player.enemy.module == Module.Laboratory)
                    {
                        var refundGameState = new GameState(Player.me);
                        foreach (var sample in Player.enemy.samples.Where(s => s.isCompleted()))
                        {
                            refundGameState.AddRefundSample(sample);
                        }

                        var refundCombination = SampleOptimization.TrySampleCombinations(refundGameState, Player.me.samples, new List<Sample>())
                                                .OrderByDescending(c => c.samples.Count)
                                                .ThenBy(c => c.state.CountMolecules()).First();

                        if (refundCombination.samples.Count > bestCombination.samples.Count)
                        {
                            bestCombination = refundCombination;
                        }
                    }

                    Player.me.bestCombination = bestCombination;

                    var missingMolecules = bestCombination.CalculateMolecules();

                    foreach (var pair in missingMolecules.OrderByDescending(p => p.Key.myCount))
                    {
                        var molecule = pair.Key;
                        int count = pair.Value;

                        if (count > 0 && molecule.count > 0)
                        {
                            Action newAction = new Action(molecule);
                            Action.AddAction(newAction);
                            return false;
                        }
                    }

                    //Stop enemy sample
                    foreach (var sample in Player.enemy.samples)
                    {
                        if (sample.canResearch())
                        {
                            foreach (var pair in sample.costs.OrderBy(p => p.Value))
                            {
                                var molecule = pair.Key;
                                int count = pair.Value;

                                if (count > 3 && molecule.count > 0)
                                {
                                    Action newAction = new Action(molecule);
                                    Action.AddAction(newAction);
                                    return false;
                                }
                            }
                        }
                    }
                }
                else
                {
                    Player.me.bestCombination = null;
                }

                if (Player.me.module == Module.Molecules)
                {
                    if (!Player.me.samples.Any(s => s.isCompleted()))
                    {
                        if (Player.me.samples.Count <= 1)
                        {
                            Action newAction = new Action(Module.Samples);
                            Action.AddAction(newAction);
                            return false;
                        }
                        else
                        {
                            Action newAction = new Action(Module.Diagnosis);
                            Action.AddAction(newAction);
                            return false;
                        }
                    }
                }
            }

            return true;
        }

        public static bool Produce()
        {
            //Produce
            if (Player.me.module == Module.Molecules)
            {
                if (false)//Player.me.samples.Count == 1)
                {
                    Action newAction = new Action(Module.Samples);
                    Action.AddAction(newAction);
                    return false;
                }
                else
                {
                    Action newAction = new Action(Module.Laboratory);
                    Action.AddAction(newAction);
                    return false;
                }
            }

            if (Player.me.module == Module.Laboratory)
            {
                if (Player.me.bestCombination != null)//Player.me.bestCombination.samples.All(s => Player.me.samples.Contains(s))
                {
                    foreach (var tSample in Player.me.bestCombination.samples)
                    {
                        var sample = Player.me.samples.FirstOrDefault(s => s.id == tSample.id);

                        if (sample != null && sample.isCompleted() && sample.health != -1)
                        {
                            Action newAction = new Action(sample);
                            Action.AddAction(newAction);
                            return false;
                        }
                    }
                }
                else
                {
                    foreach (var sample in Player.me.samples.OrderByDescending(s => s.totalCost))
                    {
                        if (sample.isCompleted() && sample.health != -1)
                        {
                            Action newAction = new Action(sample);
                            Action.AddAction(newAction);
                            return false;
                        }

                    }
                }
            }

            //Go Back Collecting
            if (Player.me.module == Module.Laboratory)
            {
                /*if (200 - Game.gameTurn < 25)
                {
                    Action newAction = new Action(Module.Molecules);
                    Action.AddAction(newAction);
                    return false;
                }*/

                //if enemy is already at lab
                if (Player.me.samples.Count > 0 && Player.enemy.module == Module.Laboratory)
                {
                    var refundGameState = new GameState(Player.me);
                    foreach (var sample in Player.enemy.samples.Where(s => s.isCompleted()))
                    {
                        refundGameState.AddRefundSample(sample);
                    }

                    var refundCombination = SampleOptimization.TrySampleCombinations(refundGameState, Player.me.samples, new List<Sample>());

                    if (refundCombination.Count > 0)
                    {
                        Action newAction = new Action(Module.Molecules);
                        Action.AddAction(newAction);
                        return false;
                    }
                }

                if (Player.me.samples.Count > 0 && Player.me.samples.Any(s => s.canCompleteSample()))
                {
                    Action newAction = new Action(Module.Molecules);
                    Action.AddAction(newAction);
                    return false;
                }
                else if (Player.me.samples.Count < 3)
                {
                    Action newAction = new Action(Module.Samples);
                    Action.AddAction(newAction);
                    return false;
                }

            }

            return true;
        }
    }
}
